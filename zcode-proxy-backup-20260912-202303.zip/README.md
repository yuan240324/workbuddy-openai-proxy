# zcode-proxy

把 **ZCode（智谱 Z.ai 官方编程 IDE）Start Plan 免费额度** 包装成本机上的
**OpenAI 兼容 + Anthropic 兼容** 接口，供 **Trae / TraeWork / TraeCode CLI / Cherry Studio** 等
任意 OpenAI 兼容客户端当作「自定义模型」接入。

> ZCode 免费额度当前为 **GLM-5.3 每天 300 万 token + GLM-5.3-Flash 每天 500 万 token**，
> 每日重置、独立计算。额度清单以 `GET /v1/models` 实时拉取（上游 `client/configs`）为准。

- **本机隔离**：只监听 `127.0.0.1:8789`，不对局域网/公网暴露，带本地 API Key 鉴权。
- **目录隔离**：配置、凭证、验证码缓存、求解器依赖**全部落在本目录内**，
  运行期不读取、不写入本目录以外的任何文件。授权走 ZCode 官方 OAuth，在你自己的浏览器里完成。
- **依赖**：服务本体零第三方依赖（Node ≥ 18）；只有验证码求解器需要 `captcha/` 内的 `happy-dom`。

---

## 0. 当前状态（2026-09-12）：**已跑通 ✅**

| 验证项 | 状态 |
|---|---|
| 阿里云无痕验证码求解 | ✅ 拿到含 securityToken 的 280 字符 verifyParam |
| 本地接口（OpenAI + Anthropic、流式、鉴权、SSE 帧） | ✅ 端到端实测通过 |
| **真实调用 ZCode 免费额度** | ✅ **成功**（GLM-5.3 真实回答） |
| 离线自测 | ✅ 46/46 |

实测样例（经本地网关，OpenAI 协议）：

```
POST http://127.0.0.1:8789/v1/chat/completions
{"model":"glm-5.3","messages":[{"role":"user","content":"用一句话说明什么是缓存穿透"}]}

→ 缓存穿透是指查询的数据在缓存和数据库中都不存在，请求每次都绕过缓存直接打到数据库…（36.7s）
```

### 关键：为什么最终走「驱动官方 CLI」这条路

自己冒充客户端 HTTP 协议会被上游判 **3012 unusual activity**（连官方桌面端都被一起拦）；
换成**驱动官方 ZCode CLI** 后，客户端指纹/版本/凭证全由正版客户端提供，请求能过风控，
只剩一个它自己解决不了的问题：**无头 CLI 没有浏览器，解不了阿里云无痕验证**（报 3007）。

本项目的做法就是把两块拼起来：

```
Trae ──OpenAI/Anthropic──▶ 本服务 /v1/*            （协议翻译 + 队列）
                              └─▶ 官方 CLI（正版身份）
                                    └─▶ 本服务 /internal/plan  ← 逐请求注入新鲜验证码
                                          └─▶ zcode.z.ai（真上游）
```

> 验证码是**一次性**的：CLI 一次 prompt 会发多个 HTTP 请求，
> 所以不能把验证码写死在配置里（那样第二个请求必然 3007），必须由内部代理逐请求注入。

### 已知限制

| 限制 | 说明 |
|---|---|
| 单次延迟 ~30–50s | CLI 要冷启 + agent 多轮；比直连慢，但稳定 |
| 同模型只允许 1 个并发 | 上游 3009；本服务已内置退避重试，并把 CLI 调用串行化 |
| `usage` 字段为 0 | CLI 文本模式不回报 token 用量（不影响使用） |
| 工具调用不透传 | CLI 是 agent，返回的是最终文本，不会产生原生 `tool_calls`；Trae 的纯对话/问答不受影响 |

### 前置条件

- 本机已安装 **ZCode 桌面端**并已登录（本服务要读 `~/.zcode/v2/config.json` 里的凭证与 provider）；
- `~/.zcode/cli/` 需要可写（启动时 CLI 配置会被自动写入）。

---

## 1. 它解决什么问题

ZCode 的免费额度（Start Plan）只对官方客户端开放，走的是这条通道：

```
POST https://zcode.z.ai/api/v1/zcode-plan/anthropic/v1/messages
Authorization: Bearer {业务 JWT}
X-Aliyun-Captcha-Verify-Param: {无痕验证参数}   ← 免费额度必需
```

本项目把这条通道包一层，对外提供标准接口，于是 Trae 不必知道 ZCode 的存在。
两处「脏活」由本项目代做：

1. **登录态**：ZCode 官方 OAuth 授权 → 业务 JWT，存 `auth.json`，过期重新 `login`。
2. **无痕验证码**：用 Node + happy-dom 在模拟浏览器里跑阿里云官方 SDK，
   算出 `X-Aliyun-Captcha-Verify-Param`（预热成小池，热路径不阻塞）。

### 1.1 上游的隐藏约定（踩坑记录，改动前务必先读）

| 约定 | 后果 |
|---|---|
| **请求体必须前置 ZCode 官方 system 身份块**（CLI Prefix / Agent Identity / Environment Info）+ 动态 `currentModel` 块 | 上游做内容审查，缺失直接拒为 **HTTP 405 + `code:3012` 「unusual activity」**（风控）。见 `src/zcode-system.json`、`src/body.mjs`；`injectZcodeBody` 别关 |
| **设备档案必须自洽** | 在一台 Windows 机上伪装 `darwin-arm64`、或系统版本与平台不匹配，都是自相矛盾信号。默认 `upstream.platform: "auto"` = 用本机真实平台/版本/语言/时区 |
| **`appVersion` 必须等于本机安装的 ZCode 客户端版本** | 本机实测 **3.11.2**（查 `ZCode.exe` 文件版本）。发旧版本会被当成非当前客户端；升级客户端后同步改 `upstream.appVersion` |
| **追踪头只发三个** | start-plan 通道只发 `x-request-id` / `x-zcode-session-type` / `x-zcode-trace-id`；多发 `x-query-id` / `x-session-id` 会被判 3012 |

**关于客户端签名（`codingPlanSignature`）**：`GET /api/v1/agent/configs` 返回 `enable: true`，
握手端点在 `api.z.ai/api/paas/c1f3a7e2/v2/client`（Ed25519 私钥 + PoW）。但从官方客户端 bundle
（`out/host/chunk-*.js`）实测确认，**本通道的三条路径在「免签名」白名单里**：

```js
new Set(["/api/v1/zcode-plan/anthropic/v1/messages",
         "/api/v1/zcode-plan/chat/completions",
         "/api/v1/off-peak/anthropic/v1/messages"])
```

所以免费额度的对话请求**不需要签名**，本项目也就不实现它（签名只对与 `api.z.ai` 同源的 coding-plan 请求生效）。

另外，poll 返回的 `data.token`（载荷含 `user_id` / `token_version`，无 `exp`）才是 Plan 通道的 Bearer；
`data.zai.access_token`（`iss: user-service`，带 `exp`）是 OAuth access token。两者别混。

---

## 2. 快速开始

### 2.1 装依赖（只需一次）

```powershell
cd captcha
npm install --cache .npm-cache        # 走 npmmirror 更快：加 --registry=https://registry.npmmirror.com
cd ..
```

### 2.2 登录（需要你在浏览器点一次授权）

```powershell
node login.mjs        # 或双击 login.cmd
```

终端会打印一条 `chat.z.ai` 授权链接并自动打开浏览器；同意后凭证写入 `auth.json`。
JWT 失效时重跑一次即可。

### 2.3 启动

```powershell
node server.mjs         # 前台（双击 start.cmd）
                        # 后台常驻：双击 start-hidden.cmd
```

启动后终端会打印监听地址、本地 API Key、默认模型与登录状态。

### 2.4 探活（判断免费额度此刻能不能用）

```powershell
node check.mjs        # 或双击 check.cmd
```

最小代价地确认一次调用，并给出退出码：
`0` 可用 / `1` 凭证问题 / `2` 上游风控（3012）/ `3` 额度耗尽 / `4` 其它。

> **遇到 3012 时不要连续重试**：这是账号/IP 级风控，官方 ZCode 客户端在同一时刻也会失败。
> 停下来等冷却（数小时/隔天），或换账号重新 `login`。

### 2.5 自检（离线，不消耗额度）

```powershell
node selftest.mjs            # 协议转换 / 流式 / 工具调用 / 官方身份块注入，共 41 项断言
node selftest.mjs --captcha  # 额外实测验证码求解（联网）
node status.mjs              # 登录态 + 免费额度
```

---

## 3. Trae 接入

> 官方限制：仅 **TraeWork 桌面版**支持添加自定义模型，且自定义模型只在本地环境可用。

**设置 → 模型 → 添加模型 → 选择「自定义模型」**：

| 参数 | 填写值 |
|---|---|
| API 格式 | **OpenAI Chat Completions 格式**（推荐） |
| 自定义请求地址 | 打开 **完整 URL** 开关，填 `http://127.0.0.1:8789/v1/chat/completions` |
| 模型 ID | `GLM-5.3`（或 `GLM-5.3-Flash`；也接受小写 `glm-5.3`） |
| 模型展示名称 | 例如 `ZCode-GLM5.3` |
| API 密钥 | `config.json` 里的 `apiKey` |

**高级配置**（建议）：

| 参数 | 建议值 |
|---|---|
| 上下文窗口 | 输入 `200000`、输出 `65536`（可留空用默认） |
| 采样参数 | 留空即可 |
| 支持图片输入 | 不勾选（GLM-5.3 为文本模型） |

改用 **Anthropic Messages 格式**也可以：完整 URL 填 `http://127.0.0.1:8789/v1/messages`，其余同上。

**「完整 URL」开关的两种填法**（任选其一，别混用）：

| API 格式 | 打开「完整 URL」 | 关闭「完整 URL」 |
|---|---|---|
| OpenAI Chat Completions | `http://127.0.0.1:8789/v1/chat/completions` | `http://127.0.0.1:8789/v1` |
| Anthropic Messages | `http://127.0.0.1:8789/v1/messages` | `http://127.0.0.1:8789/v1` |

> 服务端做了**路径后缀容错**：路径里只要含 `/chat/completions`（按 OpenAI 处理）
> 或 `/messages`（按 Anthropic 处理）就能命中，`/v1/v1/chat/completions` 这类拼重复也不会 404。

### 3.1 TraeCode CLI（`trae_cli.yaml`）

```yaml
models:
  - name: "ZCode-GLM5.3"
    open_ai:
      base_url: http://127.0.0.1:8789/v1
      api_key: "<config.json 里的 apiKey>"
      model: GLM-5.3
```

### 3.2 TRAE IDE

**设置 → 模型 → 添加自定义模型**，Base URL 填 `http://127.0.0.1:8789/v1`，API Key 与模型 ID 同上。

---

## 4. 接口一览

| 路径 | 方法 | 说明 |
|---|---|---|
| `/v1/models` | GET | 模型清单（实时取免费额度权益，失败回落配置） |
| `/v1/chat/completions` | POST | OpenAI 兼容补全（流式/非流式、工具调用、多轮工具回灌） |
| `/v1/messages` | POST | Anthropic Messages（上游即此协议，近乎透传） |
| `/v1/messages/count_tokens` | POST | token 估算 |
| `/status` | GET | 登录状态 + 免费额度 |
| `/health` | GET | 健康检查（免鉴权） |

带不带 `/v1` 前缀都能访问。鉴权：`Authorization: Bearer <apiKey>` 或 `x-api-key: <apiKey>`。

---

## 5. 目录结构

```
zcode-proxy/
├── server.mjs            # 服务入口（路由 + 鉴权 + 路径后缀容错）
├── login.mjs             # OAuth 授权登录，凭证写入 auth.json
├── status.mjs            # 登录态 + 免费额度（命令行）
├── start.cmd             # 双击启动（前台）
├── start-hidden.cmd      # 双击启动（最小化后台）
├── login.cmd / status.cmd
├── config.example.json   # 配置样例（首次启动自动生成 config.json）
├── captcha/
│   ├── solver.js         # 无痕验证求解器（Node + happy-dom）
│   ├── package.json      # 依赖声明（happy-dom）
│   └── .cdn-cache/       # alicdn 资源本地缓存（运行时生成）
└── src/
    ├── config.mjs        # 配置加载与模型名归一
    ├── auth.mjs          # 凭证存取 + 设备指纹 MID
    ├── identity.mjs      # 上游身份头仿真
    ├── captcha.mjs       # 求解器调度 + 预解池
    ├── upstream.mjs      # Plan 通道调用 + 错误分类 + 额度查询
    ├── convert.mjs       # OpenAI ⇄ Anthropic 双向转换（含流式）
    ├── openai.mjs        # /v1/chat/completions
    ├── anthropic.mjs     # /v1/messages
    ├── util.mjs          # HTTP/SSE 小工具
    └── log.mjs           # 日志
```

运行时生成、已被 `.gitignore` 忽略：`config.json`、`auth.json`、`captcha/.cdn-cache/`、`captcha/node_modules/`。

---

## 6. 常见问题

| 现象 | 处理 |
|---|---|
| `401 尚未登录` | 运行 `node login.mjs` |
| `401 上游拒绝授权` | JWT 失效，重新 `node login.mjs` |
| `429 上游风控限制（HTTP 405 code 3012 unusual activity）` | **风控拦截**。常见触发：请求体缺少 ZCode 官方 system 身份块（本项目已内置注入，勿关 `injectZcodeBody`）、设备指纹自相矛盾（勿把 `upstream.platform` 改成别的系统）、短时间高频请求。处置：停手冷却 15~30 分钟再试，必要时换账号 |
| `402 免费额度不可用` | 当日额度用尽（GLM-5.3 300 万 / Flash 500 万），次日重置 |
| `503 验证码求解失败` | 先在 `captcha/` 跑 `npm install`；或调大 `captcha.solveTimeoutMs` |
| 求解较慢 | 首次求解需下载 alicdn SDK（数秒），之后走本地缓存会快很多 |
| 模型回答被截断 | 上游「思考」也计入输出 token，调大 Trae 的输出上下文窗口 |
| 想换端口/Key | 改 `config.json` 后重启服务 |
| 关掉鉴权 | 把 `config.json` 的 `apiKey` 设为 `""`（仅本机使用时才可以） |

---

## 7. 安全与边界

- **只监听 `127.0.0.1`**；`auth.json` 权限 0600，**不要外传**、不要提交仓库。
- **只读写本目录**：运行期所有落盘操作都限定在项目目录内（含验证码缓存），
  不读取 ZCode 桌面端配置、浏览器数据或任何目录外文件。
- 走的是 **ZCode 官方客户端所用的接口**，无公开文档、可能随时变更；本项目只做本机自用转发。
- 请仅用于**本人账号**，遵守 Z.ai / 智谱相关用户协议；额度规则与风控由上游决定。
- 本项目与 Z.ai / 智谱无任何关联，未获官方授权或认可，请自行评估使用风险。

---

## 8. 致谢与许可

- 验证码求解器 `captcha/solver.js` 移植自开源项目
  [dengyie/zcode2api](https://github.com/dengyie/zcode2api) 的 `captcha_node/solver.js`
  （**AGPL-3.0**），本项目对其做了两处本地改造：
  1. CDN 缓存目录从用户主目录改为**项目目录内**（`captcha/.cdn-cache/`）；
  2. 子进程输出由管道改为**临时文件**（管道 stdio 在受限沙箱/部分环境下会 spawn EPERM）。
- 上游协议细节参考了 zcode2api 的公开文档（端点拓扑、身份头集合、验证码契约）。
- 受 AGPL-3.0 影响，**若你要分发本项目（含 solver.js），需一并遵守 AGPL-3.0**。仅本机自用不受影响。
- ZCode / Z.ai / 智谱 / Trae 均为其各自所有者的商标，本项目与上述公司无隶属关系。
