@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ZCode 免费额度 · 探活
node check.mjs
echo.
pause
