#!/usr/bin/env node
// 免费额度探活：最小代价地确认 Start Plan 通道当前是否可用。
//
//   node check.mjs
//
// 退出码：0 = 可用；1 = 凭证问题；2 = 上游风控（3012）；3 = 额度耗尽；4 = 其它
//
// 说明：上游风控（3012 unusual activity）是**账号/IP 级**的，官方 ZCode 客户端在
// 同一时刻也会报同样的错；遇到时停下等冷却，不要连续重试。
import { loadConfig } from './src/config.mjs';
import { getAuth, isLoggedIn, jwtClaims } from './src/auth.mjs';
import { CaptchaManager } from './src/captcha.mjs';
import { callMessages, UpstreamError } from './src/upstream.mjs';

const cfg = loadConfig();

console.log('ZCode 免费额度探活');
console.log(`  端点：${cfg.upstream.zcodeOrigin}${cfg.upstream.messagesPath}`);
console.log(`  客户端版本：${cfg.upstream.appVersion}（需与本机 ZCode 客户端一致）`);

if (!isLoggedIn()) {
  console.log('  登录状态：未登录 —— 请先运行 node login.mjs');
  process.exit(1);
}

const a = getAuth();
const claims = jwtClaims(a.jwt);
console.log(`  登录状态：已登录（账号 ${claims?.sub || a.rawPoll?.user?.user_id || '未知'}）`);
console.log(`  验证码：求解中…（首次可能 5~20 秒）`);

const captcha = new CaptchaManager(cfg);
const t0 = Date.now();
try {
  const res = await callMessages(
    cfg,
    captcha,
    {
      model: cfg.defaultModel,
      max_tokens: 8,
      messages: [{ role: 'user', content: 'ping' }],
    },
    { stream: false },
  );
  const text = await res.text();
  let say = text.slice(0, 160);
  try {
    const j = JSON.parse(text);
    say = (j.content || []).map((b) => b.text || '').join('').slice(0, 80) || '(空回复)';
  } catch {}
  console.log(`\n✅ 可用！HTTP ${res.status}，耗时 ${Date.now() - t0}ms`);
  console.log(`   模型回复：${say}`);
  console.log('\n下一步：node server.mjs 启动本地接口，按 README 第 3 节把 Trae 接上。');
  process.exit(0);
} catch (e) {
  if (e instanceof UpstreamError && e.status === 429 && e.riskControl) {
    console.log(`\n⛔ 上游风控拦截（3012 unusual activity），耗时 ${Date.now() - t0}ms`);
    console.log('   这是账号/IP 级限制：官方 ZCode 客户端此刻同样会失败。');
    console.log('   处置：停止重试、等待冷却（建议数小时/隔天），或换一个账号重新 login。');
    process.exit(2);
  }
  if (e instanceof UpstreamError && e.status === 402) {
    console.log(`\n📉 今日免费额度已用尽（GLM-5.3 300 万 / Flash 500 万 token，次日重置）`);
    process.exit(3);
  }
  if (e?.status === 401) {
    console.log(`\n🔑 凭证无效：${e.message}`);
    console.log('   处置：重新运行 node login.mjs');
    process.exit(1);
  }
  console.log(`\n❌ 探活失败（${Date.now() - t0}ms）：${e.message}`);
  process.exit(4);
}
