@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ZCode 反代 · 登录（浏览器授权）
node login.mjs
echo.
pause
