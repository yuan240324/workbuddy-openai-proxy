#!/usr/bin/env node
// ZCode 官方 OAuth 授权登录：access_token → 业务 JWT，写入本项目 auth.json。
//
// 只读写本项目目录内的文件（auth.json）；授权在你自己浏览器里完成。
// 不读取 ZCode 桌面端配置、浏览器数据或任何项目目录以外的文件。
//
// 注意：上游授权流程有几分钟有效期，超时会返回 3004 invalid_flow；
// 本脚本会自动换一条新链接重试（最多 5 轮），每轮都重新打开浏览器。
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { writeFileSync, readFileSync } from 'node:fs';
import { join } from 'node:path';
import { loadConfig, paths } from './src/config.mjs';
import { getAuth, saveAuth, ensureDeviceMid, jwtClaims } from './src/auth.mjs';
import { log, warn, error } from './src/log.mjs';

const cfg = loadConfig();
const ZCODE = cfg.upstream.zcodeOrigin;
const ZAI = cfg.upstream.zaiOrigin;
const UA = `ZCode/${cfg.upstream.appVersion}`;
const POLL_INTERVAL_SEC = 3;
const ROUNDS = 8; // 每轮链接约 5 分钟有效期，8 轮 ≈ 40 分钟等待窗口

class FlowExpired extends Error {}

function openBrowser(url) {
  // 多策略尝试（Windows 上 `cmd start` 在隐藏窗口/受限环境下可能静默失败）：
  //   1. PowerShell Start-Process（走 ShellExecute，最接近双击链接）
  //   2. cmd start
  //   3. rundll32 url.dll
  // 全部失败也不影响流程：链接已打印在终端，手动粘贴即可。
  const attempts =
    process.platform === 'win32'
      ? [
          ['powershell', ['-NoProfile', '-Command', `Start-Process '${url.replace(/'/g, "''")}'`]],
          ['cmd', ['/c', 'start', '', url]],
          ['rundll32', ['url.dll,FileProtocolHandler', url]],
        ]
      : process.platform === 'darwin'
        ? [['open', [url]]]
        : [['xdg-open', [url]]];

  let i = 0;
  for (const [cmd, args] of attempts) {
    i += 1;
    try {
      const child = execFile(cmd, args, (err) => {
        if (err && i === attempts.length) {
          warn(`自动打开浏览器失败（${err.message}），请手动复制上面的链接到浏览器打开。`);
        }
      });
      child.unref?.();
      return;
    } catch {
      // 试下一种
    }
  }
}

async function readJson(res) {
  const text = await res.text();
  try {
    return { json: JSON.parse(text), text };
  } catch {
    return { json: null, text };
  }
}

/**
 * 把流程状态与每次轮询的原始响应落到 .login-state.json（本目录内），
 * 便于排查「授权后拿不到 token」这类上游形态问题。
 */
function recordState(entry) {
  try {
    const p = paths.loginState;
    let state = {};
    try {
      state = JSON.parse(readFileSync(p, 'utf8'));
    } catch {}
    if (entry.flowId !== undefined) state.flowId = entry.flowId;
    if (entry.pollToken !== undefined) state.pollToken = entry.pollToken;
    if (entry.authorizeUrl !== undefined) state.authorizeUrl = entry.authorizeUrl;
    state.polls = state.polls || [];
    if (entry.poll) {
      state.polls.push(entry.poll);
      if (state.polls.length > 30) state.polls.shift();
    }
    writeFileSync(p, JSON.stringify(state, null, 2), 'utf8');
  } catch {
    // 记录失败不影响流程
  }
}

/** 深度查找形似凭证的字符串（JWT 三段点分，或名字含 token/credential 的长串）。 */
function deepFindToken(obj, depth = 0) {
  if (!obj || depth > 5) return null;
  if (typeof obj === 'string') {
    return /^[\w-]{8,}\.[\w-]{8,}\.[\w-]{8,}$/.test(obj) ? obj : null;
  }
  if (Array.isArray(obj)) {
    for (const v of obj) {
      const t = deepFindToken(v, depth + 1);
      if (t) return t;
    }
    return null;
  }
  if (typeof obj === 'object') {
    for (const [k, v] of Object.entries(obj)) {
      if (typeof v === 'string' && v.length > 20 && /token|jwt|credential|secret/i.test(k)) return v;
      const t = deepFindToken(v, depth + 1);
      if (t) return t;
    }
  }
  return null;
}

/** 发起 OAuth 流程，拿到 flow_id 与授权链接。 */
async function initFlow(pollToken) {
  const res = await fetch(`${ZCODE}${cfg.upstream.oauthInitPath}`, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${pollToken}`,
      'Content-Type': 'application/json',
      Accept: 'application/json',
      'User-Agent': UA,
    },
    body: JSON.stringify({ provider: 'zai' }),
    signal: AbortSignal.timeout(30000),
  });
  const { json, text } = await readJson(res);
  if (!res.ok || !json || json.code !== 0 || !json.data?.flow_id) {
    throw new Error(`发起授权失败（HTTP ${res.status}）：${text.slice(0, 300)}`);
  }
  return json.data;
}

/** 轮询等待用户在浏览器完成授权；流程过期抛 FlowExpired。 */
async function pollFlow(flowId, pollToken, expiresAt) {
  let lastMsg = '';
  const hardDeadline = Date.now() + 8 * 60 * 1000;

  while (Date.now() < hardDeadline) {
    let json = null;
    let status = 0;
    try {
      const res = await fetch(`${ZCODE}${cfg.upstream.oauthPollPath}/${flowId}`, {
        headers: { Authorization: `Bearer ${pollToken}`, Accept: 'application/json', 'User-Agent': UA },
        signal: AbortSignal.timeout(30000),
      });
      status = res.status;
      json = (await readJson(res)).json;
    } catch (e) {
      process.stderr.write('.');
      await sleep(POLL_INTERVAL_SEC);
      continue;
    }

    const data = json?.data || {};
    const code = json?.code;
    // 记录原始响应，便于排查上游形态变化
    recordState({ poll: { at: new Date().toISOString(), http: status, code, msg: json?.msg, data } });

    // 流程过期：换个新链接重来
    if (code === 3004 || code === 3005 || /invalid_flow|expired|not.?found/i.test(String(json?.msg || ''))) {
      throw new FlowExpired(json?.msg || `code=${code}`);
    }

    const explicit =
      data.accessToken || data.access_token || data.zcodejwttoken || data.zcodeJwtToken || data.jwt;
    const guessed = explicit ? null : deepFindToken(data);
    const token = explicit || guessed;
    if (status === 200 && code === 0 && token) {
      if (lastMsg) process.stderr.write('\n');
      if (guessed && !explicit) log('（凭据来自深度扫描字段，原始响应已记录到 .login-state.json）');
      log('授权成功，已取得凭证');
      return { data, token };
    }

    // 状态不再是 pending 但拿不到 token：把原始响应打出来，避免无声空转
    const st = String(data.status || '');
    if (code === 0 && st && !/pending|waiting|processing/i.test(st) && st !== lastMsg) {
      log(`上游状态=${st}，但响应中没有可用凭证字段；原始响应已记录到 .login-state.json`);
      log('  响应摘要：' + JSON.stringify(json).slice(0, 400));
    }

    // 429 等瞬时错误：安静等待，不刷屏
    const msg =
      status === 429
        ? '上游限流，稍等…'
        : code === 0
          ? `等待授权…（${data.status || 'pending'}）`
          : `等待授权… code=${code} ${json?.msg || ''}`;
    if (msg !== lastMsg) {
      if (lastMsg) process.stderr.write('\n');
      log(msg);
      lastMsg = msg;
    } else {
      process.stderr.write('.');
    }

    const remaining = expiresAt ? Math.round(expiresAt * 1000 - Date.now()) : null;
    await sleep(remaining !== null && remaining < 30000 ? 1 : POLL_INTERVAL_SEC);
  }
  throw new FlowExpired('轮询超时');
}

const sleep = (sec) => new Promise((r) => setTimeout(r, sec * 1000));

/** access_token → 业务 JWT（Plan 通道的 Bearer）。 */
async function loginBusiness(accessToken) {
  const res = await fetch(`${ZAI}${cfg.upstream.zaiLoginPath}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', Accept: 'application/json', 'User-Agent': UA },
    body: JSON.stringify({ token: accessToken }),
    signal: AbortSignal.timeout(30000),
  });
  const { json, text } = await readJson(res);
  if (!res.ok) {
    warn(`换取业务凭证失败（HTTP ${res.status}）：${text.slice(0, 200)}`);
    return null;
  }
  const data = json?.data || {};
  const token = data.access_token || data.accessToken || data.token || null;
  if (!token) {
    warn(`业务凭证未取到，返回字段为：${Object.keys(data).join(', ') || '(空)'}；原文 ${text.slice(0, 160)}`);
  }
  return token;
}

async function attempt(round) {
  const pollToken = crypto.randomBytes(32).toString('hex');
  const init = await initFlow(pollToken);

  log('');
  log(`[第 ${round}/${ROUNDS} 轮] 请在浏览器中完成 ZCode 授权（链接约 5 分钟内有效）：`);
  console.log('');
  console.log(init.authorize_url);
  console.log('');
  // 同时写入本目录下的 login-url.txt：浏览器打不开时可直接从文件复制
  try {
    writeFileSync(
      join(paths.root, 'login-url.txt'),
      `${init.authorize_url}\n\n生成时间：${new Date().toISOString()}\n有效期约 5 分钟；过期后本文件会被新的链接覆盖。\n`,
      'utf8',
    );
    log(`授权链接已同时写入：${join(paths.root, 'login-url.txt')}`);
  } catch (e) {
    warn(`写入 login-url.txt 失败：${e.message}`);
  }
  openBrowser(init.authorize_url);
  recordState({ flowId: init.flow_id, pollToken: init.poll_token || pollToken, authorizeUrl: init.authorize_url });

  const res = await pollFlow(init.flow_id, init.poll_token || pollToken, init.expires_at);
  return { init, data: res.data, token: res.token };
}

async function main() {
  log('ZCode 反代 · 登录');
  log(`授权端点：${ZCODE}${cfg.upstream.oauthInitPath}`);

  let last = null;
  for (let round = 1; round <= ROUNDS; round++) {
    try {
      last = await attempt(round);
      break;
    } catch (e) {
      if (e instanceof FlowExpired && round < ROUNDS) {
        warn(`授权链接已失效（${e.message}），自动生成新链接…`);
        continue;
      }
      throw e;
    }
  }
  if (!last) throw new Error('多次尝试仍未取得授权');

  const { init, data, token } = last;
  const jwtLike = (v) => typeof v === 'string' && /^[\w-]{8,}\.[\w-]{8,}\.[\w-]{8,}$/.test(v);
  // 实测 poll 成功响应形态（2026-09）：
  // { status:"ready", token:"<Plan 通道业务 JWT>", user:{user_id,email,name},
  //   zai:{access_token:"<OAuth access_token>"} }
  // 注意两者用途不同：token 是 Plan 通道 Bearer；zai.access_token 用于换业务凭证/签名握手。
  let accessToken = data.zai?.access_token || data.accessToken || data.access_token || null;
  let zcodeJwt = data.token || data.zcodejwttoken || data.zcodeJwtToken || data.jwt || null;
  if (!accessToken && !zcodeJwt && token) {
    if (jwtLike(token)) zcodeJwt = token;
    else accessToken = token;
  }
  // 已有 Plan JWT 就不必再换；业务 JWT 单独留给需要它的接口
  const bizJwt = accessToken ? await loginBusiness(accessToken) : null;
  const jwt = zcodeJwt || bizJwt;
  if (!jwt && !accessToken) throw new Error('授权已完成但未返回可用凭证');

  const a = getAuth();
  a.accessToken = accessToken || a.accessToken;
  a.zcodeJwt = zcodeJwt || a.zcodeJwt || null;
  a.bizJwt = bizJwt || a.bizJwt || null;
  a.jwt = jwt || null;
  a.flowId = init.flow_id;
  a.savedAt = new Date().toISOString();
  a.rawPoll = data;
  a.expiresAt = data.expires_at || data.expiresAt || null;
  saveAuth(a);
  ensureDeviceMid();

  const claims = jwtClaims(a.jwt);
  log('');
  log(`凭证已写入：${paths.auth}`);
  log(`  access_token：${a.accessToken ? a.accessToken.slice(0, 12) + '…' : '（无）'}`);
  log(`  业务 JWT：${a.jwt ? a.jwt.slice(0, 12) + '…' : '（无）'}`);
  if (claims?.exp) log(`  JWT 有效期至：${new Date(claims.exp * 1000).toISOString()}`);
  if (claims?.sub) log(`  账号 ID：${claims.sub}`);
  log(`  device_mid：${a.deviceMid}`);
  log('');
  log('下一步：node server.mjs 启动本地接口。');
}

main().catch((e) => {
  error(e.message || String(e));
  process.exitCode = 1;
});
