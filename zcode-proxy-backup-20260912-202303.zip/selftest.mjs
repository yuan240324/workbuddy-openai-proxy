#!/usr/bin/env node
// 离线自测：不联网、不消耗额度，验证协议转换与流式聚合的正确性。
// 用法：node selftest.mjs        （加 --captcha 额外实测验证码求解，会联网）
import { loadConfig, normalizeModel, defaultConfig } from './src/config.mjs';
import { openaiToAnthropic, normalizeAnthropic, anthropicToOpenai, streamAnthropicToOpenai } from './src/convert.mjs';

const cfg = loadConfig();
let pass = 0;
let fail = 0;

function check(name, cond, extra = '') {
  if (cond) {
    pass++;
    console.log(`  ✓ ${name}`);
  } else {
    fail++;
    console.log(`  ✗ ${name} ${extra}`);
  }
}

function sseStream(chunks) {
  return new ReadableStream({
    start(c) {
      for (const s of chunks) c.enqueue(new TextEncoder().encode(s));
      c.close();
    },
  });
}

function fakeRes() {
  return {
    destroyed: false,
    writableEnded: false,
    chunks: [],
    writeHead() {},
    flushHeaders() {},
    write(c) {
      this.chunks.push(String(c));
      return true;
    },
    end() {
      this.writableEnded = true;
    },
  };
}

const ev = (type, obj) => `event: ${type}\ndata: ${JSON.stringify(obj)}\n\n`;

console.log('\n[1] OpenAI 请求 → Anthropic 请求');
{
  const payload = openaiToAnthropic(
    {
      model: 'glm-5.3',
      stream: true,
      max_tokens: 999999,
      messages: [
        { role: 'system', content: '你是助手' },
        { role: 'developer', content: '用中文回答' },
        { role: 'user', content: [{ type: 'text', text: '你好' }] },
        {
          role: 'assistant',
          content: '我查一下',
          tool_calls: [
            { id: 'call_1', type: 'function', function: { name: 'get_weather', arguments: '{"city":"北京"}' } },
          ],
        },
        { role: 'tool', tool_call_id: 'call_1', content: '晴 26℃' },
        { role: 'user', content: '谢谢' },
      ],
      tools: [
        {
          type: 'function',
          function: {
            name: 'get_weather',
            description: '查天气',
            parameters: { type: 'object', properties: { city: { type: 'string' } } },
          },
        },
      ],
      tool_choice: 'auto',
      temperature: 0.3,
      stop: ['END'],
    },
    cfg,
  );

  check('模型名归一为官方大小写', payload.model === 'GLM-5.3', `got=${payload.model}`);
  check('system 合并 developer', payload.system === '你是助手\n\n用中文回答', `got=${payload.system}`);
  check('max_tokens 被钳制到上限', payload.max_tokens === cfg.maxTokensLimit, `got=${payload.max_tokens}`);
  check('assistant 工具调用转为 tool_use', payload.messages.some((m) => m.content?.some?.((b) => b.type === 'tool_use')));
  check('tool_result 归入 user 消息', payload.messages.some((m) => m.content?.some?.((b) => b.type === 'tool_result')));
  check('工具 schema 转为 input_schema', payload.tools?.[0]?.input_schema?.type === 'object');
  check('tool_choice auto 映射', payload.tool_choice?.type === 'auto');
  check('stop 映射为 stop_sequences', Array.isArray(payload.stop_sequences));
  check('角色交替无相邻同角色', payload.messages.every((m, i, arr) => i === 0 || arr[i - 1].role !== m.role));
  check('首条为 user', payload.messages[0].role === 'user');
}

console.log('\n[2] Anthropic 非流式响应 → OpenAI 响应');
{
  const out = anthropicToOpenai(
    {
      id: 'msg_1',
      content: [
        { type: 'thinking', thinking: '想一想' },
        { type: 'text', text: '答案是 42' },
        { type: 'tool_use', id: 'tu_1', name: 'calc', input: { a: 1 } },
      ],
      stop_reason: 'tool_use',
      usage: { input_tokens: 12, output_tokens: 34 },
    },
    'GLM-5.3',
  );
  check('文本聚合', out.choices[0].message.content === '答案是 42');
  check('思考内容进 reasoning_content', out.choices[0].message.reasoning_content === '想一想');
  check('tool_calls 结构', out.choices[0].message.tool_calls?.[0]?.function?.name === 'calc');
  check('tool_use → finish_reason=tool_calls', out.choices[0].finish_reason === 'tool_calls');
  check('usage 换算', out.usage.total_tokens === 46, JSON.stringify(out.usage));
}

console.log('\n[3] Anthropic 流式 → OpenAI 流式');
{
  const upstream = {
    body: sseStream([
      ev('message_start', { type: 'message_start', message: { id: 'msg_2', usage: { input_tokens: 7 } } }),
      ev('content_block_start', { type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } }),
      ev('content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: '你好' } }),
      ev('content_block_delta', { type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text: '，世界' } }),
      ev('content_block_stop', { type: 'content_block_stop', index: 0 }),
      ev('content_block_start', {
        type: 'content_block_start',
        index: 1,
        content_block: { type: 'tool_use', id: 'tu_9', name: 'search' },
      }),
      ev('content_block_delta', {
        type: 'content_block_delta',
        index: 1,
        delta: { type: 'input_json_delta', partial_json: '{"q":"x"}' },
      }),
      ev('content_block_stop', { type: 'content_block_stop', index: 1 }),
      ev('message_delta', { type: 'message_delta', delta: { stop_reason: 'tool_use' }, usage: { output_tokens: 9 } }),
      ev('message_stop', { type: 'message_stop' }),
    ]),
  };
  const res = fakeRes();
  const stat = await streamAnthropicToOpenai(upstream, res, 'GLM-5.3');
  const joined = res.chunks.join('');

  check('聚合文本正确', stat.text === '你好，世界', `got=${stat.text}`);
  check('finish_reason 正确', stat.finishReason === 'tool_calls', `got=${stat.finishReason}`);
  check('usage 正确', stat.usage.prompt_tokens === 7 && stat.usage.completion_tokens === 9);
  check('输出含 [DONE]', joined.includes('data: [DONE]'));
  check('工具调用首块带 id/name', /"tool_calls":\[{"index":0,"id":"tu_9","type":"function","function":{"name":"search"/.test(joined.replace(/\s/g, '')) || joined.includes('"id":"tu_9"'));
  check('工具参数增量透传', joined.includes('{\\"q\\":\\"x\\"}"') || joined.includes('{"q":"x"}'));
  check('文本增量逐块下发', joined.includes('你好') && joined.includes('，世界'));
  check('块结构 object 正确', joined.includes('"object":"chat.completion.chunk"'));
}

console.log('\n[4] 模型别名');
{
  check('小写 glm-5.3 → GLM-5.3', normalizeModel('glm-5.3', cfg) === 'GLM-5.3');
  check('glm-5.3-flash → GLM-5.3-Flash', normalizeModel('glm-5.3-flash', cfg) === 'GLM-5.3-Flash');
  check('未知模型原样透传', normalizeModel('mystery-model', cfg) === 'mystery-model');
  check('缺省模型', normalizeModel(undefined, cfg) === cfg.defaultModel);
}

console.log('\n[5] 配置完整性');
{
  const d = defaultConfig();
  check('监听地址仅本机', d.host === '127.0.0.1');
  check('端口非 8788（避开同目录另一反代）', d.port === 8789);
  check('默认带本地 API Key', /^sk-zc-/.test(d.apiKey));
  check('验证码默认开启', d.captcha.enabled === true);
  check('上游为 zcode-plan Plan 通道', d.upstream.messagesPath.includes('/zcode-plan/'));
  check('max_tokens 上限为 131072', d.maxTokensLimit === 131072);
}

console.log('\n[6] 上游「200 里塞业务错误」识别');
{
  const { parseBusinessError } = await import('./src/upstream.mjs');
  const biz = parseBusinessError('{"code":1005,"msg":"exceed quota limit"}');
  check('识别出业务错误码', biz?.code === 1005, JSON.stringify(biz));
  check('正常 Anthropic 响应不误判', parseBusinessError('{"type":"message","content":[],"usage":{}}') === null);
  check('正常 OpenAI 响应不误判', parseBusinessError('{"choices":[{"message":{"content":"hi"}}]}') === null);
  check('code=0 不算错误', parseBusinessError('{"code":0,"msg":"","data":{}}') === null);
  check('非 JSON 不误判', parseBusinessError('event: message_start\n') === null);
}

console.log('\n[7] ZCode 官方 system 身份块注入（缺了会被上游判 3012 风控）');
{
  const { transformBody } = await import('./src/body.mjs');
  const body = {
    model: 'GLM-5.3',
    messages: [{ role: 'user', content: 'hi' }],
    system: '你是我自己的提示',
  };
  transformBody(body, { userId: 'u-123', model: 'GLM-5.3' });
  check(
    'system 首块为官方标识',
    Array.isArray(body.system) && body.system[0]?.text === 'You are ZCode, an interactive coding agent',
  );
  check('含 Environment 段', body.system.some((b) => String(b.text).includes('# Environment')));
  check(
    '含动态 currentModel 块',
    body.system.some((b) => String(b.text).includes('powered by the model named GLM-5.3')),
  );
  check('保留客户端原有 system', body.system.some((b) => b.text === '你是我自己的提示'));
  check('官方块带 cache_control', body.system.some((b) => b.cache_control?.type === 'ephemeral'));
  check('最后一条非 system 消息加 cache_control', body.messages[0].content[0]?.cache_control?.type === 'ephemeral');
  check('注入 metadata.user_id', body.metadata?.user_id === 'u-123');

  const snapshot = JSON.stringify(body);
  transformBody(body, { userId: 'u-123', model: 'GLM-5.3' });
  check('变换幂等（重复执行不叠加）', JSON.stringify(body) === snapshot);
}

if (process.argv.includes('--captcha')) {
  console.log('\n[7] 验证码求解（联网，可能耗时 10~30s）');
  const { CaptchaManager } = await import('./src/captcha.mjs');
  const cm = new CaptchaManager(cfg);
  try {
    const tok = await cm.get();
    const decoded = JSON.parse(Buffer.from(tok.param, 'base64').toString('utf8'));
    check('取得 verifyParam', typeof tok.param === 'string' && tok.param.length > 200);
    check('含 securityToken', Boolean(decoded.securityToken) && decoded.securityToken.length >= 50);
    check('sceneId 与配置一致', decoded.sceneId === cfg.captcha.sceneId, `got=${decoded.sceneId}`);
  } catch (e) {
    check('验证码求解', false, e.message);
  }
}

console.log(`\n结果：${pass} 通过 / ${fail} 失败`);
process.exitCode = fail ? 1 : 0;
