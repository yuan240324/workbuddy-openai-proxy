#!/usr/bin/env node
// zcode-proxy：把 ZCode Start Plan 免费额度（GLM-5.3 / GLM-5.3-Flash）包装成本机上的
// OpenAI 兼容 + Anthropic 兼容接口，供 Trae 等客户端接成「自定义模型」。
//
// 只监听 127.0.0.1；凭证与配置全部落在本项目目录内。
import http from 'node:http';
import { existsSync } from 'node:fs';
import { sep } from 'node:path';
import { loadConfig, paths } from './src/config.mjs';
import { isLoggedIn, getAuth } from './src/auth.mjs';
import { CaptchaManager } from './src/captcha.mjs';
import { createPlanProxy } from './src/plan-proxy.mjs';
import { handleChatCompletions } from './src/openai.mjs';
import { handleMessages, handleCountTokens } from './src/anthropic.mjs';
import { queryQuota } from './src/upstream.mjs';
import { sendJson, sendError } from './src/util.mjs';
import { log, warn, error } from './src/log.mjs';

const cfg = loadConfig();
const captcha = new CaptchaManager(cfg);
const planProxy = createPlanProxy(cfg, captcha);

function authorized(req) {
  if (!cfg.apiKey) return true; // 留空则不校验（仅本机使用）
  const h = req.headers['authorization'] || '';
  const bearer = h.replace(/^Bearer\s+/i, '').trim();
  const key = req.headers['x-api-key'];
  return bearer === cfg.apiKey || key === cfg.apiKey;
}

async function models() {
  // 模型清单以免费额度（client/configs → startPlanPreview）实时返回为准，失败回落配置
  try {
    const url = `${cfg.upstream.zcodeOrigin}${cfg.upstream.configsPath}?app_version=${cfg.upstream.appVersion}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
    const json = await res.json();
    const ents = json?.data?.configs?.startPlanPreview?.entitlements;
    if (Array.isArray(ents) && ents.length) {
      return ents.map((e) => ({
        id: e.showName,
        name: `${e.showName}（免费 ${Math.round((e.grantUnits || 0) / 10000)} 万 token/${e.period === 'daily' ? '日' : e.period}）`,
        grant_units: e.grantUnits,
        period: e.period,
      }));
    }
  } catch {
    // 忽略：用配置里的兜底清单
  }
  return cfg.models;
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || '127.0.0.1'}`);
  const path = url.pathname;
  const method = req.method || 'GET';

  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
  if (method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  try {
    // 健康检查：免鉴权
    if (path.endsWith('/health') || path === '/') {
      sendJson(res, 200, {
        ok: true,
        service: 'zcode-proxy',
        logged_in: isLoggedIn(),
        default_model: cfg.defaultModel,
        captcha_enabled: cfg.captcha.enabled,
      });
      return;
    }

    // 内部 Plan 代理：供本机官方 CLI 使用（CLI 的 provider baseURL 指向这里）。
    // 不校验本地 API Key（只监听 127.0.0.1），作用仅是**逐请求注入新鲜验证码**后转发上游。
    if (path.startsWith('/internal/plan')) {
      const chunks = [];
      for await (const c of req) chunks.push(c);
      await planProxy(req, res, Buffer.concat(chunks));
      return;
    }

    if (!authorized(req)) {
      sendError(res, 401, '本地 API Key 不正确（见 config.json 的 apiKey）', 'authentication_error');
      return;
    }

    if (path.endsWith('/status')) {
      const a = getAuth();
      sendJson(res, 200, {
        logged_in: isLoggedIn(),
        jwt_prefix: a.jwt ? String(a.jwt).slice(0, 12) + '…' : null,
        device_mid: a.deviceMid || null,
        saved_at: a.savedAt || null,
        quota: await queryQuota(cfg),
      });
      return;
    }

    if (path.endsWith('/models')) {
      const list = await models();
      sendJson(res, 200, {
        object: 'list',
        data: list.map((m) => ({
          id: m.id,
          object: 'model',
          created: Math.floor(Date.now() / 1000),
          owned_by: 'zcode',
          name: m.name,
        })),
      });
      return;
    }

    // 路径后缀容错：客户端把路径拼重复也能命中
    if (path.includes('/chat/completions') && method === 'POST') {
      await handleChatCompletions(req, res, cfg, captcha);
      return;
    }
    if (path.includes('count_tokens') && method === 'POST') {
      await handleCountTokens(req, res);
      return;
    }
    if (path.includes('/messages') && method === 'POST') {
      await handleMessages(req, res, cfg, captcha);
      return;
    }

    sendError(res, 404, `未知路径 ${method} ${path}`, 'not_found_error');
  } catch (e) {
    const status = e.status || 500;
    warn(`请求失败 ${method} ${path}：${e.message}`);
    if (!res.headersSent) sendError(res, status, e.message || '内部错误');
    else res.end();
  }
});

server.listen(cfg.port, cfg.host, () => {
  log('zcode-proxy 已启动');
  log(`  监听地址：http://${cfg.host}:${cfg.port}   （仅本机可达）`);
  log(`  API Key：${cfg.apiKey || '（未设置，不校验）'}`);
  log(`  默认模型：${cfg.defaultModel}`);
  log(`  登录状态：${isLoggedIn() ? '已登录' : '未登录 —— 请先运行 node login.mjs'}`);
  log(`  验证码：${cfg.captcha.enabled ? '启用（免费额度必需）' : '已关闭'}`);
  log(`  配置：${paths.config}`);
  if (cfg.captcha.enabled && !existsSync(paths.captchaDir + sep + 'node_modules')) {
    warn(`  验证码求解器依赖缺失：请先在 ${paths.captchaDir} 执行 npm install --cache .npm-cache`);
  }
  if (isLoggedIn()) captcha.startWarmup(() => isLoggedIn());
});

process.on('unhandledRejection', (e) => error('未处理的 Promise 拒绝：', e?.message || e));
