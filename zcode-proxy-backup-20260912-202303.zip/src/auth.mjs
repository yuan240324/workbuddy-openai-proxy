// 凭证管理：access_token / 业务 JWT / device_mid 只保存在本项目目录内的 auth.json。
// 登录通过 ZCode 官方 OAuth 授权流程获得，不读取 ZCode 客户端或任何项目外文件。
import fs from 'node:fs';
import crypto from 'node:crypto';
import { paths } from './config.mjs';
import { warn } from './log.mjs';

export class AuthError extends Error {
  constructor(message, code = 'auth_error') {
    super(message);
    this.code = code;
    this.status = code === 'not_logged_in' ? 401 : 500;
  }
}

let auth = null;
let loadedMtime = -1;

/** 读取 auth.json（按 mtime 缓存）：登录脚本在服务运行期间写入也能被自动感知。 */
export function loadAuth() {
  let mtime = 0;
  try {
    mtime = fs.statSync(paths.auth).mtimeMs;
  } catch {
    mtime = 0;
  }
  if (auth && mtime === loadedMtime) return auth;
  loadedMtime = mtime;
  if (!mtime) auth = {};
  else {
    try {
      auth = JSON.parse(fs.readFileSync(paths.auth, 'utf8'));
    } catch (e) {
      warn('auth.json 解析失败，视作未登录：', e.message);
      auth = {};
    }
  }
  return auth;
}

export function getAuth() {
  return loadAuth();
}

export function saveAuth(next = getAuth()) {
  auth = next;
  fs.writeFileSync(paths.auth, JSON.stringify(auth, null, 2) + '\n', { encoding: 'utf8', mode: 0o600 });
  loadedMtime = fs.statSync(paths.auth).mtimeMs;
  return auth;
}

/** 稳定的设备指纹 MID（UUIDv4，首次生成后永久复用，禁止逐请求抖动）。 */
export function ensureDeviceMid() {
  const a = getAuth();
  if (!a.deviceMid) {
    a.deviceMid = crypto.randomUUID();
    saveAuth(a);
  }
  return a.deviceMid;
}

/** Plan 通道（免费额度）用的 Bearer 凭证：优先 JWT，其次 OAuth access_token。 */
export function planToken() {
  const a = getAuth();
  const token = a.jwt || a.zcodeJwt || a.accessToken;
  if (!token) throw new AuthError('尚未登录：请先运行 node login.mjs 完成 ZCode 授权', 'not_logged_in');
  return token;
}

export function isLoggedIn() {
  const a = getAuth();
  return Boolean(a.jwt || a.zcodeJwt || a.accessToken);
}

/** 解析 JWT 载荷（不验签，仅取 sub/exp 用于展示与过期判断）。 */
export function jwtClaims(token) {
  try {
    const payload = String(token).split('.')[1];
    if (!payload) return null;
    return JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
  } catch {
    return null;
  }
}

/** token 是否已过期（能判断才判断；判断不了返回 false，由上游 401 兜底）。 */
export function tokenExpired(token) {
  const claims = jwtClaims(token);
  if (!claims?.exp) return false;
  return Date.now() > claims.exp * 1000;
}
