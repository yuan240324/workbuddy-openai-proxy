// 请求体变换：对齐 ZCode 官方客户端在 Plan（免费额度）通道上的三项变换。
//
// 1. system 身份块：前置 ZCode 官方 system 块 + 动态 currentModel 块。
//    **上游会做内容审查，请求缺这些身份块会被直接拒为 3012
//    "request has been blocked due to unusual activity"（HTTP 405）** —— 这是
//    实测踩过的坑，不是可选优化。
// 2. cache_control：最后一条非 system 消息的最后一个 content block 追加
//    `cache_control: {type:"ephemeral"}`（低于缓存门槛时上游静默忽略，安全）。
// 3. metadata.user_id：从 JWT 解出 user_id 注入。
//
// 所有变换对畸形输入保持 no-op：坏请求永远不会被这里放大。
import fs from 'node:fs';
import path from 'node:path';
import { paths } from './config.mjs';

let BLOCKS = [];
try {
  BLOCKS = JSON.parse(fs.readFileSync(path.join(paths.root, 'src', 'zcode-system.json'), 'utf8'));
} catch {
  BLOCKS = [];
}

const clone = (v) => JSON.parse(JSON.stringify(v));

/** 把客户端原有 system 归一为 text block 列表。 */
export function normalizeUserSystem(system) {
  if (system == null) return [];
  if (typeof system === 'string') {
    return system.trim() ? [{ type: 'text', text: system }] : [];
  }
  if (!Array.isArray(system)) return [];
  const out = [];
  for (const item of system) {
    if (typeof item === 'string') {
      if (item.trim()) out.push({ type: 'text', text: item });
    } else if (item && typeof item === 'object' && item.type === 'text' && typeof item.text === 'string') {
      if (item.text.trim()) {
        const block = { type: 'text', text: item.text };
        if (item.cache_control && typeof item.cache_control === 'object') block.cache_control = item.cache_control;
        out.push(block);
      }
    }
  }
  return out;
}

/** 前置官方身份块（幂等：已前置则跳过）。保留客户端原有 system 于官方块之后。 */
export function applyStartPlanSystem(body, model) {
  if (!BLOCKS.length) return false;
  const existing = body.system;
  if (Array.isArray(existing) && existing.length) {
    const first = existing[0];
    if (first && typeof first === 'object' && first.text === BLOCKS[0].text) return false;
  }
  const official = BLOCKS.map(clone);
  if (typeof model === 'string' && model.trim()) {
    official.push({
      type: 'text',
      text: `- You are powered by the model named ${model}.`,
      cache_control: { type: 'ephemeral' },
    });
  }
  body.system = official.concat(normalizeUserSystem(existing));
  return true;
}

/** 最后一条非 system 消息的最后一个 block 加 ephemeral 缓存标记（幂等）。 */
export function applyCacheControl(body) {
  const messages = body.messages;
  if (!Array.isArray(messages) || !messages.length) return false;
  for (let i = messages.length - 1; i >= 0; i--) {
    const msg = messages[i];
    if (!msg || typeof msg !== 'object') continue;
    if (msg.role === 'system') continue;
    const content = msg.content;
    if (typeof content === 'string') {
      msg.content = [{ type: 'text', text: content, cache_control: { type: 'ephemeral' } }];
      return true;
    }
    if (Array.isArray(content) && content.length) {
      const last = content[content.length - 1];
      if (last && typeof last === 'object' && !last.cache_control) {
        last.cache_control = { type: 'ephemeral' };
        return true;
      }
    }
    return false;
  }
  return false;
}

/** 注入 metadata.user_id（保留已有 metadata 其它字段，幂等）。 */
export function applyUserId(body, userId) {
  if (!userId) return false;
  const existing = body.metadata;
  const merged = existing && typeof existing === 'object' && !Array.isArray(existing) ? { ...existing } : {};
  if (merged.user_id === userId) return false;
  merged.user_id = userId;
  body.metadata = merged;
  return true;
}

/** 从 JWT 载荷取 user_id（sub / user_id）。 */
export function jwtUserId(token) {
  if (!token || String(token).split('.').length !== 3) return null;
  try {
    const payload = JSON.parse(Buffer.from(String(token).split('.')[1], 'base64url').toString('utf8'));
    const id = payload?.user_id || payload?.sub;
    return id ? String(id) : null;
  } catch {
    return null;
  }
}

/** 按 Plan 通道变换 body（原地修改并返回）。变换失败静默保持原样。 */
export function transformBody(body, { userId = null, model = null } = {}) {
  try {
    applyStartPlanSystem(body, model);
    applyCacheControl(body);
    applyUserId(body, userId);
  } catch {
    // 变换永不放大请求失败
  }
  return body;
}
