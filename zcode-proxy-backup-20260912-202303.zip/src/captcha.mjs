// 阿里云无痕验证求解：通过 Node 子进程在 happy-dom 模拟浏览器环境中运行官方 SDK，
// 求得 X-Aliyun-Captcha-Verify-Param（免费 Plan 通道每次请求都必须携带）。
//
// 求解有秒级 CPU 开销，故维护一个小型预解池：热路径直接取现成 token，后台补货。
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { paths } from './config.mjs';
import { log, warn } from './log.mjs';

export class CaptchaError extends Error {
  constructor(message) {
    super(message);
    this.status = 503;
    this.code = 'captcha_failed';
  }
}

class Token {
  constructor(param, region) {
    this.param = param;
    this.region = region;
    this.bornAt = Date.now();
  }
  expired(ttlMs) {
    return Date.now() - this.bornAt >= ttlMs;
  }
}

export class CaptchaManager {
  constructor(cfg) {
    this.cfg = cfg;
    this.pool = [];
    this.refilling = false;
    this.configCache = null;
    this.configCacheAt = 0;
    this.lastError = null;
    this.timer = null;
    this.staleFiles = [];
    this.lastUseAt = 0; // 最近一次真实请求时间（用于空转保护）
    this.sweepStale();
  }

  /** 清扫上次运行遗留的临时输出文件（崩溃/被强杀时可能残留）。 */
  sweepStale() {
    try {
      for (const f of fs.readdirSync(paths.captchaDir)) {
        if (/^\.solve-\d+-\d+-[a-z0-9]+\.(out|err)$/i.test(f)) {
          try {
            fs.unlinkSync(path.join(paths.captchaDir, f));
          } catch {}
        }
      }
    } catch {}
  }

  /** 上游下发的验证码配置（sceneId/region/prefix），失败回落配置文件默认值。 */
  async fetchConfig() {
    const now = Date.now();
    if (this.configCache && now - this.configCacheAt < 10 * 60 * 1000) return this.configCache;
    const c = this.cfg.captcha;
    const fallback = { sceneId: c.sceneId, region: c.region, prefix: c.prefix, enabled: c.enabled };
    try {
      const url = `${this.cfg.upstream.zcodeOrigin}${this.cfg.upstream.configsPath}?app_version=${this.cfg.upstream.appVersion}`;
      const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
      const json = await res.json();
      const captcha = json?.data?.configs?.captcha;
      if (captcha?.sceneId) {
        this.configCache = captcha;
        this.configCacheAt = now;
        return captcha;
      }
    } catch (e) {
      warn('拉取验证码配置失败，使用本地默认：', e.message);
    }
    return fallback;
  }

  /** 起一个求解子进程，成功返回 verifyParam。 */
  solve(scene, region, prefix) {
    const solver = paths.captchaSolver;
    if (!fs.existsSync(solver)) {
      throw new CaptchaError(`未找到验证码求解器 ${solver}`);
    }
    const nodeModules = paths.captchaDir + '\\node_modules';
    if (!fs.existsSync(nodeModules)) {
      throw new CaptchaError(
        `验证码求解器依赖缺失：请先在 ${paths.captchaDir} 执行 npm install --cache .npm-cache`,
      );
    }
    const timeoutMs = this.cfg.captcha.solveTimeoutMs;
    // 子进程输出走临时文件而非管道：管道 stdio 在受限沙箱下会 spawn EPERM，写文件则到处可用。
    const stamp = `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const outFile = path.join(paths.captchaDir, `.solve-${stamp}.out`);
    const errFile = path.join(paths.captchaDir, `.solve-${stamp}.err`);

    return new Promise((resolve, reject) => {
      let settled = false;
      let outFd;
      let errFd;
      try {
        outFd = fs.openSync(outFile, 'w');
        errFd = fs.openSync(errFile, 'w');
      } catch (e) {
        reject(new CaptchaError(`无法创建求解器输出文件：${e.message}`));
        return;
      }
      const cleanup = () => {
        try {
          fs.closeSync(outFd);
        } catch {}
        try {
          fs.closeSync(errFd);
        } catch {}
        // 立即删除（此时子进程已 close、本进程 fd 已关；用 unref 定时器会因进程先退出而漏删）
        for (const f of [outFile, errFile]) {
          try {
            fs.unlinkSync(f);
          } catch {
            // Windows 上偶发占用：留给下次启动时的清扫
            this.staleFiles.push(f);
          }
        }
      };

      const child = spawn(process.execPath, [solver, scene, region, prefix], {
        cwd: paths.captchaDir,
        windowsHide: true,
        stdio: ['ignore', outFd, errFd],
      });
      const timer = setTimeout(() => {
        if (settled) return;
        settled = true;
        try {
          child.kill();
        } catch {}
        cleanup();
        reject(new CaptchaError(`验证码求解超时（${timeoutMs}ms）`));
      }, timeoutMs);

      child.on('error', (e) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        cleanup();
        reject(new CaptchaError(`无法启动求解器：${e.message}`));
      });
      child.on('close', () => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        let stdout = '';
        let stderr = '';
        try {
          stdout = fs.readFileSync(outFile, 'utf8');
        } catch {}
        try {
          stderr = fs.readFileSync(errFile, 'utf8');
        } catch {}
        cleanup();
        const line = stdout.split(/\r?\n/).find((l) => l.startsWith('VERIFY_PARAM='));
        const param = line ? line.slice('VERIFY_PARAM='.length).trim() : null;
        if (param) resolve(param);
        else
          reject(
            new CaptchaError(
              `验证码求解失败：${(stderr.trim().split(/\r?\n/).pop() || '求解器无输出').slice(0, 200)}`,
            ),
          );
      });
    });
  }

  /** 求解一枚（带重试）。 */
  async solveOne() {
    const conf = await this.fetchConfig();
    const retries = this.cfg.captcha.retries || 3;
    let lastErr = null;
    for (let i = 1; i <= retries; i++) {
      try {
        const param = await this.solve(
          conf.sceneId || this.cfg.captcha.sceneId,
          conf.region || this.cfg.captcha.region,
          conf.prefix || this.cfg.captcha.prefix,
        );
        if (i > 1) log(`验证码求解成功（第 ${i} 次尝试）`);
        return new Token(param, conf.region || this.cfg.captcha.region);
      } catch (e) {
        lastErr = e;
        warn(`第 ${i}/${retries} 次验证码求解失败：${e.message}`);
      }
    }
    this.lastError = lastErr?.message;
    throw new CaptchaError(`验证码求解失败：${this.lastError || '多次重试无结果'}`);
  }

  /** 取一枚可用 verifyParam：优先池内现成的，池空则同步现解。 */
  async get() {
    if (!this.cfg.captcha.enabled) return null;
    this.lastUseAt = Date.now();
    const ttl = this.cfg.captcha.cacheTtlMs;
    while (this.pool.length) {
      const tok = this.pool.shift();
      if (!tok.expired(ttl)) {
        this.refill(1); // fire-and-forget 补货
        return tok;
      }
    }
    const tok = await this.solveOne();
    this.refill(1);
    return tok;
  }

  /** 上游报验证码挑战：整池作废（这批 token 已被盯上，继续用只会连环 3007）。 */
  invalidate() {
    if (this.pool.length) {
      warn(`验证码失效，清空池 ${this.pool.length} 枚`);
      this.pool = [];
    }
    this.configCache = null;
    this.configCacheAt = 0;
  }

  /** 后台补货到 poolMin（串行，避免并发爆 Node 进程）。 */
  async refill(need) {
    if (this.refilling) return;
    const { poolMin, poolMax, cacheTtlMs } = this.cfg.captcha;
    this.pool = this.pool.filter((t) => !t.expired(cacheTtlMs));
    if (this.pool.length + need > poolMax - poolMin && this.pool.length >= poolMin) return;
    this.refilling = true;
    try {
      while (this.pool.length < poolMin) {
        const tok = await this.solveOne();
        if (this.pool.length >= poolMax) break;
        this.pool.push(tok);
      }
    } catch (e) {
      warn('验证码预热失败：', e.message);
    } finally {
      this.refilling = false;
    }
  }

  /**
   * 后台预热循环（服务启动时调用）。
   * 只在「最近有请求」时才补货：求解本身就是上游流量（会加剧风控），
   * 空转的代理不该在没人用的时候一直打上游。
   */
  startWarmup(isUsable) {
    if (this.timer) return;
    const IDLE_STOP_MS = 5 * 60 * 1000; // 超过 5 分钟没人用就停手
    this.timer = setInterval(() => {
      if (!isUsable()) return;
      if (!this.lastUseAt || Date.now() - this.lastUseAt > IDLE_STOP_MS) return;
      this.refill(1).catch(() => {});
    }, 5000);
    this.timer.unref?.();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}
