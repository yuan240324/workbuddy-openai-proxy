// 配置与路径：所有文件（配置、凭证、验证码求解器）一律限定在本项目目录内，
// 绝不读写项目目录以外的文件。
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

export const ROOT = path.resolve(import.meta.dirname, '..');

export const paths = {
  root: ROOT,
  config: path.join(ROOT, 'config.json'),
  auth: path.join(ROOT, 'auth.json'),
  loginState: path.join(ROOT, '.login-state.json'),
  logFile: path.join(ROOT, 'proxy.log'),
  captchaDir: path.join(ROOT, 'captcha'),
  captchaSolver: path.join(ROOT, 'captcha', 'solver.js'),
};

// ZCode 上游模型名大小写敏感（GLM-5.3 / GLM-5.3-Flash），对外用小写别名更好用。
export const MODEL_NAME_MAP = {
  'glm-5.3': 'GLM-5.3',
  'glm-5.3-flash': 'GLM-5.3-Flash',
  'glm-5.2': 'GLM-5.2',
  'glm-5-turbo': 'GLM-5-Turbo',
  'glm-turbo': 'GLM-5-Turbo',
  'glm-5.1': 'GLM-5.1',
  'glm-4.7': 'GLM-4.7',
};

// Start Plan 免费额度当前涵盖的模型（真实额度以 client/configs 实时返回为准）
export const DEFAULT_MODELS = [
  { id: 'GLM-5.3', name: 'GLM-5.3（免费额度 300 万 token/日）' },
  { id: 'GLM-5.3-Flash', name: 'GLM-5.3-Flash（免费额度 500 万 token/日）' },
];

export function defaultConfig() {
  return {
    host: '127.0.0.1', // 仅本机可访问
    port: 8789, // 与同目录 workbuddy 反代（8788）错开
    apiKey: 'sk-zc-' + crypto.randomBytes(12).toString('hex'),
    defaultModel: 'GLM-5.3',
    defaultMaxTokens: 32768,
    // 后端选择：
    //   'cli'  = 驱动官方 ZCode CLI（推荐）——正版客户端身份能过上游风控，
    //            验证码由本项目求解后注入 CLI 配置；
    //   'http' = 直接冒充客户端 HTTP 协议（会被上游判 3012 unusual activity，仅备查）
    backend: 'cli',
    cli: {
      path: '', // 留空自动探测官方 CLI（zcode.cjs）
      providerId: 'builtin:bigmodel-start-plan', // 官方应用配置里的 provider
      model: 'GLM-5.3',
      mode: 'plan', // plan 模式只读、不擅自改文件，行为最接近纯聊天
      timeoutMs: 240000,
      concurrencyRetries: 3, // 上游 3009 并发受限时的退避重试次数
    },
    // 上游 max_tokens 合法上限（超出上游报 400 code 1210），网关统一钳制
    maxTokensLimit: 131072,
    // 是否注入 ZCode 官方 system 身份块（缺失会被上游拒为 3012 风控，务必保持 true）
    injectZcodeBody: true,
    stripFields: [],
    upstream: {
      zcodeOrigin: 'https://zcode.z.ai',
      zaiOrigin: 'https://api.z.ai',
      // Plan 通道（免费额度走这条，需要无痕验证码头）
      messagesPath: '/api/v1/zcode-plan/anthropic/v1/messages',
      // API Key 回退通道（免验证码，用不上时保持未登录即可）
      fallbackMessagesPath: '/api/anthropic/v1/messages',
      configsPath: '/api/v1/client/configs',
      billingBase: '/api/v1/zcode-plan',
      oauthInitPath: '/api/v1/oauth/cli/init',
      oauthPollPath: '/api/v1/oauth/cli/poll',
      zaiLoginPath: '/api/auth/z/login',
      // 客户端版本：必须与**本机安装的 ZCode 客户端**版本一致（过期版本会被上游判异常）。
      // 本机实测 3.11.2；升级客户端后同步改这里。Windows 上可查 ZCode.exe 的文件版本。
      appVersion: '3.11.2',
      // 设备档案：'auto' = 用本机真实平台（推荐，伪装成别的系统反而可疑）
      platform: 'auto',
      osVersion: '', // 留空 = 本机真实系统版本
      osVersionFallback: '10.0.22631',
      releaseChannel: 'production',
      clientLanguage: '', // 留空 = 本机语言
      clientTimezone: '', // 留空 = 本机时区
      title: 'Z Code@cli',
      referer: 'https://zcode.z.ai/',
      agent: 'glm',
    },
    captcha: {
      enabled: true,
      sceneId: '11xygtvd',
      region: 'cn',
      prefix: 'no8xfe',
      solveTimeoutMs: 45000, // 单次求解（Node 子进程）超时
      cacheTtlMs: 60000, // 单枚 verifyParam 可用时长
      poolMin: 1, // 后台预热目标枚数（预热本身就是上游流量，从紧设置）
      poolMax: 3, // 池上限
      retries: 3,
    },
    timeouts: {
      headerMs: 120000,
      idleMs: 300000,
    },
    models: DEFAULT_MODELS,
    modelAliases: {},
  };
}

function deepMerge(base, over) {
  if (Array.isArray(base) || Array.isArray(over)) return over ?? base;
  if (typeof base !== 'object' || base === null || typeof over !== 'object' || over === null) {
    return over === undefined ? base : over;
  }
  const out = { ...base };
  for (const [k, v] of Object.entries(over)) out[k] = deepMerge(base[k], v);
  return out;
}

export function loadConfig() {
  if (!fs.existsSync(paths.config)) {
    const cfg = defaultConfig();
    fs.writeFileSync(paths.config, JSON.stringify(cfg, null, 2) + '\n', 'utf8');
    return cfg;
  }
  const raw = JSON.parse(fs.readFileSync(paths.config, 'utf8'));
  return deepMerge(defaultConfig(), raw);
}

/** 允许的模型名归一：小写别名 → 官方名；未知模型原样透传（由上游报错）。 */
export function normalizeModel(name, cfg) {
  if (!name) return cfg.defaultModel;
  const aliases = cfg.modelAliases || {};
  if (aliases[name]) return aliases[name];
  const lower = String(name).toLowerCase();
  if (aliases[lower]) return aliases[lower];
  return MODEL_NAME_MAP[lower] || name;
}
