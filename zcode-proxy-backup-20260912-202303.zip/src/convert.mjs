// 协议转换：OpenAI Chat Completions ⇄ Anthropic Messages。
// 上游是 Anthropic 协议，故 /v1/messages 近乎透传；/v1/chat/completions 需要双向翻译。
import { normalizeModel } from './config.mjs';
import { writeSSE } from './util.mjs';

let counter = 0;
const nextToolId = () => `toolu_${Date.now().toString(36)}${(counter++).toString(36)}`;

// ── 请求：OpenAI → Anthropic ────────────────────────────────────────────────

function textOf(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content
      .map((p) => (typeof p === 'string' ? p : p?.type === 'text' || p?.type === 'input_text' ? p.text : ''))
      .filter(Boolean)
      .join('');
  }
  return '';
}

function imageBlock(part) {
  const url = part.image_url?.url || part.image_url || '';
  const m = /^data:([^;,]+);base64,(.+)$/s.exec(String(url));
  if (m) return { type: 'image', source: { type: 'base64', media_type: m[1], data: m[2] } };
  if (/^https?:/.test(String(url))) return { type: 'image', source: { type: 'url', url: String(url) } };
  return null;
}

function contentToBlocks(content) {
  if (typeof content === 'string') return content ? [{ type: 'text', text: content }] : [];
  if (!Array.isArray(content)) return [];
  const blocks = [];
  for (const part of content) {
    if (typeof part === 'string') {
      if (part) blocks.push({ type: 'text', text: part });
      continue;
    }
    if (!part || typeof part !== 'object') continue;
    if (part.type === 'text' || part.type === 'input_text') {
      if (part.text) blocks.push({ type: 'text', text: part.text });
    } else if (part.type === 'image_url' || part.type === 'image') {
      const b = imageBlock(part);
      if (b) blocks.push(b);
    }
  }
  return blocks;
}

function toolChoiceToAnthropic(choice) {
  if (!choice) return null;
  if (typeof choice === 'string') {
    if (choice === 'auto') return { type: 'auto' };
    if (choice === 'required' || choice === 'any') return { type: 'any' };
    if (choice === 'none') return null;
    return { type: 'auto' };
  }
  if (choice.type === 'function' && choice.function?.name) {
    return { type: 'tool', name: choice.function.name };
  }
  if (choice.type === 'any' || choice.type === 'tool' || choice.type === 'auto') return choice;
  return { type: 'auto' };
}

/** OpenAI 请求体 → Anthropic Messages 请求体。 */
export function openaiToAnthropic(body, cfg) {
  const messages = Array.isArray(body.messages) ? body.messages : [];
  const systemParts = [];
  const out = [];

  const push = (msg) => {
    const last = out[out.length - 1];
    // Anthropic 要求 user/assistant 交替：同角色相邻消息合并
    if (last && last.role === msg.role) {
      const a = Array.isArray(last.content) ? last.content : [{ type: 'text', text: String(last.content) }];
      const b = Array.isArray(msg.content) ? msg.content : [{ type: 'text', text: String(msg.content) }];
      last.content = [...a, ...b];
      return;
    }
    out.push(msg);
  };

  for (const m of messages) {
    const role = m?.role;
    if (role === 'system' || role === 'developer') {
      const t = textOf(m.content);
      if (t) systemParts.push(t);
      continue;
    }
    if (role === 'tool' || role === 'function') {
      const block = {
        type: 'tool_result',
        tool_use_id: m.tool_call_id || m.name || '',
        content: textOf(m.content) || '(空结果)',
      };
      const last = out[out.length - 1];
      // 连续工具结果合并进同一条 user 消息（Anthropic 要求 tool_result 紧跟其后）
      if (last && last.role === 'user' && Array.isArray(last.content) && last.content.every((b) => b.type === 'tool_result')) {
        last.content.push(block);
      } else {
        push({ role: 'user', content: [block] });
      }
      continue;
    }
    if (role === 'assistant') {
      const blocks = [];
      const t = textOf(m.content);
      if (t) blocks.push({ type: 'text', text: t });
      for (const tc of m.tool_calls || []) {
        let input = {};
        const args = tc?.function?.arguments;
        if (typeof args === 'string' && args.trim()) {
          try {
            input = JSON.parse(args);
          } catch {
            input = { _raw: args };
          }
        } else if (args && typeof args === 'object') {
          input = args;
        }
        blocks.push({
          type: 'tool_use',
          id: tc?.id || nextToolId(),
          name: tc?.function?.name || tc?.name || 'unknown_tool',
          input,
        });
      }
      if (!blocks.length) blocks.push({ type: 'text', text: '' });
      push({ role: 'assistant', content: blocks });
      continue;
    }
    // user
    const blocks = contentToBlocks(m.content);
    if (blocks.length) push({ role: 'user', content: blocks });
  }

  // Anthropic 要求首条必须是 user
  if (out.length && out[0].role !== 'user') {
    out.unshift({ role: 'user', content: [{ type: 'text', text: '(继续)' }] });
  }

  const maxTokens = Math.min(
    Number(body.max_tokens) > 0 ? Number(body.max_tokens) : cfg.defaultMaxTokens,
    cfg.maxTokensLimit,
  );

  const payload = {
    model: normalizeModel(body.model, cfg),
    max_tokens: maxTokens,
    messages: out,
    stream: Boolean(body.stream),
  };
  if (systemParts.length) payload.system = systemParts.join('\n\n');
  if (typeof body.temperature === 'number') payload.temperature = body.temperature;
  if (typeof body.top_p === 'number') payload.top_p = body.top_p;
  if (body.stop) payload.stop_sequences = Array.isArray(body.stop) ? body.stop : [body.stop];
  if (Array.isArray(body.tools) && body.tools.length) {
    payload.tools = body.tools
      .map((t) => {
        const fn = t?.function || t;
        if (!fn?.name) return null;
        return {
          name: fn.name,
          description: fn.description || '',
          input_schema: fn.parameters || { type: 'object', properties: {} },
        };
      })
      .filter(Boolean);
    const tc = toolChoiceToAnthropic(body.tool_choice);
    if (tc) payload.tool_choice = tc;
  }
  return payload;
}

/** 归一 Anthropic 请求体（/v1/messages 直连上游前做参数钳制与模型名归一）。 */
export function normalizeAnthropic(body, cfg) {
  const payload = { ...body };
  payload.model = normalizeModel(body.model, cfg);
  const mt = Number(body.max_tokens);
  payload.max_tokens = Math.min(mt > 0 ? mt : cfg.defaultMaxTokens, cfg.maxTokensLimit);
  return payload;
}

// ── 响应：Anthropic → OpenAI ───────────────────────────────────────────────

const STOP_MAP = {
  end_turn: 'stop',
  stop_sequence: 'stop',
  max_tokens: 'length',
  tool_use: 'tool_calls',
  pause_turn: 'stop',
  refusal: 'stop',
};

function usageOf(usage) {
  const i = usage?.input_tokens || 0;
  const o = usage?.output_tokens || 0;
  return { prompt_tokens: i, completion_tokens: o, total_tokens: i + o };
}

/** 非流式 Anthropic 响应 → OpenAI completion 对象。 */
export function anthropicToOpenai(json, model) {
  let text = '';
  let thinking = '';
  const toolCalls = [];
  for (const block of json?.content || []) {
    if (block.type === 'text') text += block.text || '';
    else if (block.type === 'thinking') thinking += block.thinking || '';
    else if (block.type === 'tool_use') {
      toolCalls.push({
        id: block.id,
        type: 'function',
        function: { name: block.name, arguments: JSON.stringify(block.input ?? {}) },
      });
    }
  }
  const message = { role: 'assistant', content: text };
  if (thinking) message.reasoning_content = thinking;
  if (toolCalls.length) message.tool_calls = toolCalls;
  return {
    id: json?.id || `chatcmpl_${Date.now().toString(36)}`,
    object: 'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model: model || json?.model || '',
    choices: [
      {
        index: 0,
        message,
        finish_reason: STOP_MAP[json?.stop_reason] || 'stop',
      },
    ],
    usage: usageOf(json?.usage),
  };
}

/** 读上游 SSE 流，产出 {event, data} 序列。 */
async function* sseEvents(res) {
  const decoder = new TextDecoder();
  let buf = '';
  const parse = (raw) => {
    let event = null;
    let data = '';
    for (const line of raw.split(/\r?\n/)) {
      if (line.startsWith('event:')) event = line.slice(6).trim();
      else if (line.startsWith('data:')) data += line.slice(5).trim();
    }
    return { event, data };
  };
  for await (const chunk of res.body) {
    buf += decoder.decode(chunk, { stream: true });
    let idx;
    while ((idx = buf.indexOf('\n\n')) >= 0) {
      const raw = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      if (raw.trim()) yield parse(raw);
    }
  }
  if (buf.trim()) yield parse(buf);
}

/**
 * Anthropic SSE 流 → OpenAI SSE 流。
 * 返回聚合后的统计（含完整文本，便于日志/调试）。
 */
export async function streamAnthropicToOpenai(upstreamRes, res, model, opts = {}) {
  const id = `chatcmpl_${Date.now().toString(36)}${(counter++).toString(36)}`;
  const created = Math.floor(Date.now() / 1000);
  const chunk = (delta, finishReason = null, extra = {}) =>
    JSON.stringify({
      id,
      object: 'chat.completion.chunk',
      created,
      model,
      choices: [{ index: 0, delta, finish_reason: finishReason }],
      ...extra,
    });

  let sentRole = false;
  let toolIndex = -1;
  let finishReason = 'stop';
  let usage = { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 };
  let fullText = '';

  const send = async (delta, finishReasonValue = null, extra = {}) => {
    await writeSSE(res, chunk(delta, finishReasonValue, extra));
  };

  for await (const ev of sseEvents(upstreamRes)) {
    if (!ev.data) continue;
    let payload;
    try {
      payload = JSON.parse(ev.data);
    } catch {
      continue;
    }
    const type = ev.event || payload.type;

    if (type === 'message_start') {
      const msg = payload.message || {};
      usage.prompt_tokens = msg.usage?.input_tokens || 0;
      if (!sentRole) {
        sentRole = true;
        await send({ role: 'assistant', content: '' });
      }
      continue;
    }

    if (type === 'content_block_start') {
      const block = payload.content_block || {};
      if (block.type === 'tool_use') {
        toolIndex += 1;
        await send({
          tool_calls: [
            {
              index: toolIndex,
              id: block.id,
              type: 'function',
              function: { name: block.name, arguments: '' },
            },
          ],
        });
      } else if (block.type === 'thinking' && block.thinking) {
        await send({ reasoning_content: block.thinking });
      }
      continue;
    }

    if (type === 'content_block_delta') {
      const d = payload.delta || {};
      if (d.type === 'text_delta' && d.text) {
        fullText += d.text;
        await send({ content: d.text });
      } else if (d.type === 'thinking_delta' && d.thinking) {
        await send({ reasoning_content: d.thinking });
      } else if (d.type === 'input_json_delta' && d.partial_json) {
        const idx = Math.max(toolIndex, 0);
        await send({ tool_calls: [{ index: idx, function: { arguments: d.partial_json } }] });
      }
      continue;
    }

    if (type === 'message_delta') {
      const d = payload.delta || {};
      if (d.stop_reason) finishReason = STOP_MAP[d.stop_reason] || 'stop';
      if (payload.usage?.output_tokens) usage.completion_tokens = payload.usage.output_tokens;
      continue;
    }

    if (type === 'message_stop') {
      usage.total_tokens = usage.prompt_tokens + usage.completion_tokens;
      await send({}, finishReason, opts.includeUsage ? { usage } : {});
      break;
    }

    if (type === 'error') {
      const msg = payload.error?.message || '上游流式错误';
      await writeSSE(res, JSON.stringify({ error: { message: msg, type: 'upstream_error' } }));
      break;
    }
  }

  await writeSSE(res, '[DONE]');
  return { id, finishReason, usage, text: fullText };
}

export { STOP_MAP, sseEvents };
