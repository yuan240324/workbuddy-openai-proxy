// 上游身份头仿真：对齐官方 ZCode 客户端的 companion 头集合（缺失会提高风控关注度）。
//
// 设备档案默认取**本机真实平台**（对齐参考实现「模仿真机安装」的默认策略）：
// 在一台 Windows 机器上伪装成 macOS，本身就是一个自相矛盾的信号。
// 可用 config.json 的 upstream.platform / osVersion / clientLanguage / clientTimezone 覆盖。
import crypto from 'node:crypto';
import os from 'node:os';

export function hostProfile() {
  const platform = process.platform; // win32 | darwin | linux
  const arch = process.arch; // x64 | arm64
  let timezone = 'UTC';
  let language = 'en-US';
  try {
    const resolved = Intl.DateTimeFormat().resolvedOptions();
    if (resolved.timeZone) timezone = resolved.timeZone;
    if (resolved.locale) language = normalizeLocale(resolved.locale);
  } catch {
    // 保留兜底值
  }
  return {
    platform,
    arch,
    osVersion: os.release(),
    timezone,
    language,
  };
}

/** Intl 可能给出 zh-CN-u-nu-latn 这类带扩展的标签，裁到 lang-REGION。 */
function normalizeLocale(tag) {
  const m = String(tag).match(/^([a-zA-Z]{2,3})(?:[-_]([a-zA-Z]{2}))?/);
  if (!m) return 'en-US';
  return m[2] ? `${m[1].toLowerCase()}-${m[2].toUpperCase()}` : m[1].toLowerCase();
}

function osCategory(platform) {
  if (platform === 'darwin' || platform === 'macos') return 'macos';
  if (platform === 'win32' || platform === 'windows') return 'windows';
  return 'linux';
}

/** 解析「平台-架构」：auto/空 → 本机真实平台；否则用配置值。 */
function resolvePlatform(cfg) {
  const raw = String(cfg.upstream.platform || 'auto').trim();
  if (!raw || raw === 'auto') {
    const host = hostProfile();
    return { platform: host.platform, arch: host.arch };
  }
  const [platform, arch = 'x64'] = raw.split('-');
  return { platform, arch };
}

/** 完整身份头（字段顺序对齐官方客户端；X-Device-Mid 稳定复用，禁止逐请求随机）。 */
export function identityHeaders(cfg, deviceMid) {
  const u = cfg.upstream;
  const { platform, arch } = resolvePlatform(cfg);
  const host = hostProfile();

  return {
    'HTTP-Referer': u.referer,
    'User-Agent': `ZCode/${u.appVersion}`,
    'X-ZCode-App-Version': u.appVersion,
    'X-Title': u.title,
    'X-ZCode-Agent': u.agent,
    'X-Platform': `${platform}-${arch}`,
    'X-Release-Channel': u.releaseChannel,
    'X-Client-Language': u.clientLanguage || host.language,
    'X-Client-Timezone': u.clientTimezone || host.timezone,
    'X-Os-Category': osCategory(platform),
    'X-Os-Version': u.osVersion || (platform === host.platform ? host.osVersion : u.osVersionFallback || '10.0.22631'),
    'X-Device-Mid': deviceMid,
  };
}

/** 追踪头（每请求全新 UUID）。start-plan 通道只发这三个，多发自找 3012 风控。 */
export function traceHeaders() {
  return {
    'x-request-id': crypto.randomUUID(),
    'x-zcode-session-type': 'main',
    'x-zcode-trace-id': crypto.randomUUID(),
  };
}
