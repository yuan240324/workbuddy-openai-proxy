// 日志：统一带时间戳输出到 stderr，避免污染 stdout 的 SSE/JSON 输出。
const ts = () => new Date().toISOString().replace('T', ' ').slice(0, 19);

export function log(...args) {
  process.stderr.write(`[${ts()}] ${args.map(String).join(' ')}\n`);
}

export function warn(...args) {
  process.stderr.write(`[${ts()}] WARN ${args.map(String).join(' ')}\n`);
}

export function error(...args) {
  process.stderr.write(`[${ts()}] ERROR ${args.map(String).join(' ')}\n`);
}
