// /v1/chat/completions：OpenAI 兼容入口（Trae / Cursor / Cherry Studio 等）。
import { readJsonBody, sendJson, sendError, startSSE } from './util.mjs';
import { openaiToAnthropic, anthropicToOpenai, streamAnthropicToOpenai } from './convert.mjs';
import { callMessages, UpstreamError } from './upstream.mjs';
import { normalizeModel } from './config.mjs';
import { log, warn } from './log.mjs';

export async function handleChatCompletions(req, res, cfg, captcha) {
  // CLI 后端：交给官方 CLI 跑，再按 OpenAI 协议回写
  if ((cfg.backend || 'cli') === 'cli') {
    const { handleWithCli } = await import('./cli-backend.mjs');
    return handleWithCli(req, res, cfg, captcha, { anthropic: false });
  }

  const body = await readJsonBody(req);
  const model = normalizeModel(body.model, cfg);
  const payload = openaiToAnthropic(body, cfg);
  const started = Date.now();

  try {
    const upstream = await callMessages(cfg, captcha, payload, { stream: Boolean(body.stream) });

    if (body.stream) {
      startSSE(res);
      const stat = await streamAnthropicToOpenai(upstream, res, model, {
        includeUsage: Boolean(body.stream_options?.include_usage),
      });
      res.end();
      log(
        `${model} 流式完成 ${Date.now() - started}ms 输出 ${stat.usage.completion_tokens} token` +
          `（输入 ${stat.usage.prompt_tokens}）`,
      );
      return;
    }

    const text = await upstream.text();
    let json;
    try {
      json = JSON.parse(text);
    } catch {
      sendError(res, 502, `上游返回非 JSON：${text.slice(0, 200)}`);
      return;
    }
    sendJson(res, 200, anthropicToOpenai(json, model));
    log(
      `${model} 完成 ${Date.now() - started}ms 输出 ${json?.usage?.output_tokens || 0} token` +
        `（输入 ${json?.usage?.input_tokens || 0}）`,
    );
  } catch (e) {
    if (e instanceof UpstreamError) {
      warn(`上游失败：${e.message}`);
      sendError(res, e.status, e.message, e.type);
      return;
    }
    throw e;
  }
}
