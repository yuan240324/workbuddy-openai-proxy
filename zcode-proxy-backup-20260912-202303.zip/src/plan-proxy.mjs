// 内部 Plan 通道代理：官方 CLI 把请求打到本服务，由本服务**逐请求**注入新鲜验证码，
// 再原样转发给真正的上游。
//
// 为什么必须逐请求注入：CLI 一次 prompt 会发多个 HTTP 请求（agent 多轮），
// 而阿里云无痕验证参数是一次性的 —— 把验证码写死在配置里，第二个请求必然 3007。
//
// 同时 CLI 的请求头原样透传（正版客户端身份），本服务只加验证码两行。
import { withIdleTimeout } from './util.mjs';
import { log, warn } from './log.mjs';

const HOP_BY_HOP = new Set([
  'host',
  'connection',
  'content-length',
  'transfer-encoding',
  'keep-alive',
  'upgrade',
  'proxy-authorization',
  'proxy-authenticate',
  'te',
  'trailer',
]);

export function createPlanProxy(cfg, captcha) {
  const target = cfg.upstream.zcodeOrigin + cfg.upstream.messagesPath;

  return async function handlePlanProxy(req, res, rawBody) {
    const started = Date.now();
    let tok;
    try {
      tok = await captcha.get();
    } catch (e) {
      warn('验证码求解失败，拒绝转发：', e.message);
      res.writeHead(503, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ type: 'error', error: { type: 'captcha_error', message: e.message } }));
      return;
    }

    // 原样透传 CLI 的请求头，只替换/补充验证码与目标
    const headers = {};
    for (const [k, v] of Object.entries(req.headers)) {
      if (HOP_BY_HOP.has(k.toLowerCase())) continue;
      if (k.toLowerCase().startsWith('x-aliyun-captcha')) continue; // 去掉旧的，换新的
      headers[k] = Array.isArray(v) ? v.join(', ') : v;
    }
    headers['X-Aliyun-Captcha-Verify-Param'] = tok.param;
    if (tok.region) headers['X-Aliyun-Captcha-Verify-Region'] = tok.region;

    let upstream;
    try {
      upstream = await fetch(target, {
        method: 'POST',
        headers,
        body: rawBody && rawBody.length ? rawBody : undefined,
      });
    } catch (e) {
      warn('转发上游失败：', e.message);
      res.writeHead(502, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ type: 'error', error: { type: 'upstream_error', message: e.message } }));
      return;
    }

    // 回写状态与内容类型；SSE 原样流式回传
    const outHeaders = {};
    const ct = upstream.headers.get('content-type');
    if (ct) outHeaders['Content-Type'] = ct;
    res.writeHead(upstream.status, outHeaders);

    if (!upstream.body) {
      res.end();
      return;
    }
    const body = withIdleTimeout(upstream.body, cfg.timeouts.idleMs);
    try {
      for await (const chunk of body) {
        if (!res.write(chunk)) await new Promise((r) => res.once('drain', r));
      }
      res.end();
    } catch (e) {
      warn('转发流中断：', e.message);
      res.end();
    }
    log(`Plan 代理 ${upstream.status} ${Date.now() - started}ms（已验证码注入）`);
  };
}
