// 上游（ZCode Plan 通道）调用：Anthropic Messages 协议 + 免费额度所需的无痕验证码头。
import { identityHeaders, traceHeaders } from './identity.mjs';
import { ensureDeviceMid, planToken } from './auth.mjs';
import { transformBody, jwtUserId } from './body.mjs';
import { withIdleTimeout, settleWithin } from './util.mjs';
import { warn } from './log.mjs';

export class UpstreamError extends Error {
  constructor(message, status, opts = {}) {
    super(message);
    this.status = status;
    this.type = opts.type || 'upstream_error';
    this.exhausted = Boolean(opts.exhausted);
    this.rateLimited = Boolean(opts.rateLimited);
    this.riskControl = Boolean(opts.riskControl);
  }
}

const EXHAUST_KEYWORDS = /(quota|insufficient|balance|exhaust|额度|余额不足|欠费)/i;

/**
 * 上游会把业务错误塞在 **HTTP 200** 里（实测：`{"code":1005,"msg":"exceed quota limit"}`），
 * 直接当成功会造成「空回复」假象。真实 Anthropic 响应带 `type` / `content`，据此区分。
 */
export function parseBusinessError(text) {
  if (!text) return null;
  let j;
  try {
    j = JSON.parse(text);
  } catch {
    return null;
  }
  if (!j || typeof j !== 'object' || Array.isArray(j)) return null;
  if (typeof j.code !== 'number' || j.code === 0) return null;
  if (j.type || j.content || j.choices) return null; // 正常响应
  return j;
}

// 上游业务码 → 本地语义（码值与含义来自官方客户端 bundle：1005=quota_exhausted 等）
const BIZ_CODES = {
  1005: { status: 402, type: 'insufficient_quota', message: '免费额度已用尽（上游 quota_exhausted，次日重置）' },
  1006: { status: 401, type: 'authentication_error', message: '凭证失效，请重新运行 node login.mjs' },
  1120: { status: 502, type: 'upstream_error', message: '上游服务错误' },
  1210: { status: 400, type: 'invalid_request_error', message: '请求参数非法（max_tokens 等超出上游范围）' },
  1211: { status: 404, type: 'not_found_error', message: '模型不存在' },
  3001: { status: 400, type: 'invalid_request_error', message: '请求参数非法' },
  3002: { status: 429, type: 'rate_limit_error', message: '上游繁忙，请稍后重试' },
  3006: { status: 400, type: 'invalid_request_error', message: '该模型当前不可用（上游 model not allowed）' },
  3007: { status: 403, type: 'captcha_error', message: '验证码被上游拒绝' },
  3008: { status: 429, type: 'rate_limit_error', message: '并发超限，请稍后重试' },
  3009: { status: 429, type: 'rate_limit_error', message: '模型并发超限（同一模型同时只能跑一个请求）' },
  3010: { status: 429, type: 'rate_limit_error', message: '已达套餐上限' },
  3012: { status: 429, type: 'rate_limit_error', message: '上游风控拦截（3012 unusual activity）' },
  2007: { status: 429, type: 'rate_limit_error', message: '上游限流，请稍后重试' },
};

function classifyBusinessError(j) {
  const spec = BIZ_CODES[j.code];
  const raw = String(j.msg || '').trim();
  if (spec) {
    const err = new UpstreamError(`${spec.message}${raw ? `（上游原话：${raw}）` : ''}`, spec.status, {
      type: spec.type,
      exhausted: spec.status === 402,
      rateLimited: spec.status === 429,
      riskControl: j.code === 3012,
    });
    err.upstreamCode = j.code;
    return err;
  }
  const err = new UpstreamError(`上游业务错误 code=${j.code}${raw ? `：${raw}` : ''}`, 502, {
    type: 'upstream_error',
  });
  err.upstreamCode = j.code;
  return err;
}

/**
 * 调试用：把实际发往上游的请求打到 stderr（设 ZCODE_DUMP=1 开启）。
 * Authorization 只留前缀，避免整串凭证进日志。
 */
function dumpRequest(url, headers, payload) {
  const masked = { ...headers };
  if (masked.Authorization) masked.Authorization = String(masked.Authorization).slice(0, 22) + '…';
  const sys = Array.isArray(payload.system) ? payload.system : [];
  process.stderr.write(
    '\n[ZCODE_DUMP] POST ' + url + '\n' +
      '  headers: ' + JSON.stringify(masked, null, 1) + '\n' +
      `  body: model=${payload.model} stream=${payload.stream} max_tokens=${payload.max_tokens} ` +
      `messages=${(payload.messages || []).length} tools=${(payload.tools || []).length} ` +
      `system_blocks=${sys.length} metadata=${JSON.stringify(payload.metadata || {})}\n` +
      '  system[0].text: ' + JSON.stringify(String(sys[0]?.text || '').slice(0, 80)) + '\n' +
      '  system texts: ' + sys.map((b) => String(b.text || '').slice(0, 34).replace(/\n/g, ' ')).join(' | ') + '\n\n',
  );
}

/** 判断上游响应是否属于「验证码挑战」（需要换一枚 verifyParam 原地重试）。 */
export function isCaptchaChallenge(status, text) {
  if (status === 403 && /(captcha|verify|challenge|人机|验证码)/i.test(text)) return true;
  if (status === 400 && /"code"\s*:\s*3007/.test(text)) return true;
  if (/(captcha|verify_param|人机校验)/i.test(text) && status >= 400 && status < 500) return true;
  return false;
}

/** 把上游错误归一成本地错误语义。 */
export function classifyUpstream(status, text) {
  const body = String(text || '');
  if (status === 402 || EXHAUST_KEYWORDS.test(body)) {
    return new UpstreamError(`免费额度不可用（HTTP ${status}）：${body.slice(0, 300)}`, 402, {
      type: 'insufficient_quota',
      exhausted: true,
    });
  }
  if (status === 429 || status === 405) {
    const risk = status === 405 || /"code"\s*:\s*3012|unusual activity/i.test(body);
    return new UpstreamError(
      `${risk ? '上游风控限制' : '上游限流'}（HTTP ${status}）：${body.slice(0, 300)}`,
      429,
      { type: 'rate_limit_error', rateLimited: true, riskControl: risk },
    );
  }
  if (status === 401 || status === 403) {
    return new UpstreamError(
      `上游拒绝授权（HTTP ${status}）：${body.slice(0, 300)}；若为登录失效请重新运行 node login.mjs`,
      401,
      { type: 'authentication_error' },
    );
  }
  if (status === 404) {
    return new UpstreamError(`上游端点不存在（404）：${body.slice(0, 200)}`, 404, { type: 'not_found_error' });
  }
  return new UpstreamError(`上游错误（HTTP ${status}）：${body.slice(0, 400)}`, status >= 400 && status < 600 ? status : 502, {
    type: 'upstream_error',
  });
}

/**
 * 包装成功响应：给流加空闲超时、给整体读取加超时，避免上游卡死挂住连接。
 *
 * 注意 body 必须**惰性**包装：withIdleTimeout 内部会 getReader() 锁住 body，
 * 一旦提前执行，后面 res.text() 就会报 “Body has already been read”。
 */
function wrapUpstream(cfg, res) {
  const idleMs = cfg.timeouts.idleMs;
  let wrappedBody = null;
  return {
    status: res.status,
    headers: res.headers,
    get body() {
      if (!wrappedBody) wrappedBody = withIdleTimeout(res.body, idleMs);
      return wrappedBody;
    },
    text: () => settleWithin(res.text(), idleMs),
  };
}

/**
 * 调用上游 Messages 接口。
 * 免费 Plan 通道带验证码头；遇验证码挑战自动换码重试（最多 3 次）。
 * 返回 fetch 的 Response（body 未消费，可透传流）。
 */
export async function callMessages(cfg, captcha, payload, { stream = false } = {}) {
  const url = cfg.upstream.zcodeOrigin + cfg.upstream.messagesPath;
  const deviceMid = ensureDeviceMid();
  const token = planToken();
  const maxAttempts = 3;

  // 官方身份块 / cache_control / metadata.user_id：缺了会被上游判 3012 风控
  if (cfg.injectZcodeBody !== false) {
    transformBody(payload, { userId: jwtUserId(token), model: payload.model });
  }

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    const headers = {
      Authorization: `Bearer ${token}`,
      'anthropic-version': '2023-06-01',
      'Content-Type': 'application/json',
      Accept: stream ? 'text/event-stream' : 'application/json',
      ...identityHeaders(cfg, deviceMid),
      ...traceHeaders(),
    };

    if (cfg.captcha.enabled) {
      const tok = await captcha.get();
      if (tok) {
        headers['X-Aliyun-Captcha-Verify-Param'] = tok.param;
        if (tok.region) headers['X-Aliyun-Captcha-Verify-Region'] = tok.region;
      }
    }

    if (process.env.ZCODE_DUMP) dumpRequest(url, headers, payload);

    const ac = new AbortController();
    const headerTimer = setTimeout(() => ac.abort(new Error('上游响应超时')), cfg.timeouts.headerMs);
    let res;
    try {
      res = await fetch(url, {
        method: 'POST',
        headers,
        body: JSON.stringify(payload),
        signal: ac.signal,
      });
    } catch (e) {
      clearTimeout(headerTimer);
      const msg = e?.name === 'AbortError' || /aborted|timeout/i.test(String(e?.message))
        ? `上游响应超时（${cfg.timeouts.headerMs}ms）`
        : `连接上游失败：${e.message}`;
      throw new UpstreamError(msg, 504, { type: 'upstream_timeout' });
    }
    clearTimeout(headerTimer); // 响应头已到，后续流不受此超时限制

    // 处理 HTTP 200：既可能是正常响应，也可能是「200 里塞业务错误」的伪成功。
    if (res.ok) {
      const ctype = String(res.headers.get('content-type') || '');
      const looksJson = ctype.includes('application/json');

      // 正常流式响应（要的是流，且上游确实回 SSE）→ 直接透传
      if (stream && !looksJson) return wrapUpstream(cfg, res);

      // 其余情况先读体，判断是不是业务错误
      const bodyText = await res.text();
      const biz = parseBusinessError(bodyText);
      if (biz) {
        // 验证码被拒：换一枚码原地重试
        if (biz.code === 3007 && attempt < maxAttempts) {
          warn(`上游拒绝验证码（第 ${attempt} 次），换码重试`);
          captcha.invalidate();
          continue;
        }
        throw classifyBusinessError(biz);
      }
      // 正常响应：回一个「体已读完」的包装，供上层解析
      return {
        status: res.status,
        headers: res.headers,
        text: async () => bodyText,
        get body() {
          return new ReadableStream({
            start(c) {
              c.enqueue(new TextEncoder().encode(bodyText));
              c.close();
            },
          });
        },
      };
    }

    const text = await res.text().catch(() => '');
    if (isCaptchaChallenge(res.status, text) && attempt < maxAttempts) {
      warn(`上游要求验证码（第 ${attempt} 次），换码重试`);
      captcha.invalidate();
      continue;
    }
    throw classifyUpstream(res.status, text);
  }
  throw new UpstreamError('上游连续要求验证码，已重试 3 次仍未通过', 503, { type: 'captcha_failed' });
}

/** 查询免费额度（Start Plan 权益 + 已用量）。任意一步失败都不影响主流程。 */
export async function queryQuota(cfg) {
  const out = { plan: null, balances: null, error: null };
  try {
    const url = `${cfg.upstream.zcodeOrigin}${cfg.upstream.configsPath}?app_version=${cfg.upstream.appVersion}`;
    const res = await fetch(url, { signal: AbortSignal.timeout(15000) });
    const json = await res.json();
    out.plan = json?.data?.configs?.startPlanPreview || null;
  } catch (e) {
    out.error = e.message;
  }
  try {
    const token = planToken();
    const deviceMid = ensureDeviceMid();
    const url = `${cfg.upstream.zcodeOrigin}${cfg.upstream.billingBase}/billing/balance`;
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${token}`,
        Accept: 'application/json',
        ...identityHeaders(cfg, deviceMid),
      },
      signal: AbortSignal.timeout(15000),
    });
    if (res.ok) {
      const json = await res.json();
      out.balances = json?.data?.balances || json?.data || null;
    }
  } catch {
    // billing 端点有 WAF，失败属正常，静默忽略
  }
  return out;
}
