// HTTP 小工具：请求体读取、响应写出（含背压）、SSE 帧写出。
export const MAX_BODY = 16 * 1024 * 1024;

export async function readJsonBody(req) {
  const chunks = [];
  let size = 0;
  for await (const chunk of req) {
    size += chunk.length;
    if (size > MAX_BODY) throw Object.assign(new Error('请求体过大（上限 16MB）'), { status: 413 });
    chunks.push(chunk);
  }
  if (!size) return {};
  const text = Buffer.concat(chunks).toString('utf8');
  try {
    return JSON.parse(text);
  } catch {
    throw Object.assign(new Error('请求体不是合法 JSON'), { status: 400 });
  }
}

export function sendJson(res, status, obj) {
  const body = JSON.stringify(obj);
  if (res.headersSent) return;
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

export function sendError(res, status, message, type = 'upstream_error') {
  sendJson(res, status, { error: { message, type, code: status } });
}

/** 带背压的写出：客户端读得慢时等待 drain，避免内存堆积。 */
export function writeAsync(res, chunk) {
  if (res.destroyed || res.writableEnded) return Promise.resolve(false);
  return new Promise((resolve) => {
    const ok = res.write(chunk);
    if (ok) resolve(true);
    else res.once('drain', () => resolve(true));
  });
}

export function startSSE(res, extraHeaders = {}) {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream; charset=utf-8',
    'Cache-Control': 'no-cache, no-transform',
    Connection: 'keep-alive',
    'X-Accel-Buffering': 'no',
    ...extraHeaders,
  });
  if (typeof res.flushHeaders === 'function') res.flushHeaders();
}

export function writeSSE(res, payload) {
  return writeAsync(res, `data: ${payload}\n\n`);
}

export function writeSSEEvent(res, event, payload) {
  return writeAsync(res, `event: ${event}\ndata: ${payload}\n\n`);
}

export function estimateTokens(text) {
  if (!text) return 0;
  return Math.max(1, Math.ceil(String(text).length / 3));
}

/** fetch 超时封装：返回 Response，超时抛错（区别于网络错误）。 */
export async function fetchWithTimeout(url, opts = {}, timeoutMs = 60000) {
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(new Error('timeout')), timeoutMs);
  try {
    return await fetch(url, { ...opts, signal: ac.signal });
  } finally {
    clearTimeout(timer);
  }
}

/** 给失败加超时（用于整段读取，如非流式响应体）。 */
export function settleWithin(promise, ms, message = '读取上游响应超时') {
  return Promise.race([
    promise,
    new Promise((_, reject) => setTimeout(() => reject(new Error(message)), ms).unref?.()),
  ]);
}

/**
 * 流的空闲超时：两个数据块之间超过 idleMs 就中断，避免上游卡死把连接一直挂着。
 * 返回新的 ReadableStream（可继续用 for await / reader 消费）。
 */
export function withIdleTimeout(body, idleMs, message = `上游流空闲超时（${idleMs}ms）`) {
  if (!body || typeof body.getReader !== 'function') return body;
  const reader = body.getReader();
  return new ReadableStream({
    async pull(controller) {
      let timer;
      const timeout = new Promise((_, reject) => {
        timer = setTimeout(() => reject(new Error(message)), idleMs);
      });
      try {
        const { done, value } = await Promise.race([reader.read(), timeout]);
        clearTimeout(timer);
        if (done) controller.close();
        else controller.enqueue(value);
      } catch (e) {
        clearTimeout(timer);
        try {
          await reader.cancel(e);
        } catch {}
        controller.error(e);
      }
    },
    cancel(reason) {
      return reader.cancel(reason).catch(() => {});
    },
  });
}
