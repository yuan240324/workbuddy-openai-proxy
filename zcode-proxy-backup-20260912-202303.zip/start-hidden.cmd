@echo off
cd /d "%~dp0"
start "" /min cmd /c "node server.mjs"
echo 已在最小化窗口后台启动（仅监听 127.0.0.1）。
timeout /t 3 >nul
