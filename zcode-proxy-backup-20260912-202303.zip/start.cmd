@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo ZCode 反代 · 启动（前台，Ctrl+C 停止）
node server.mjs
echo.
pause
