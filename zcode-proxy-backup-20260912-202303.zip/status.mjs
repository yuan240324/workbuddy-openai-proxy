#!/usr/bin/env node
// 查看登录状态与免费额度（等价于访问本地 /status）。
import { loadConfig } from './src/config.mjs';
import { isLoggedIn, getAuth } from './src/auth.mjs';

const cfg = loadConfig();
const base = `http://${cfg.host}:${cfg.port}`;

if (!isLoggedIn()) {
  console.log('登录状态：未登录 —— 请先运行 node login.mjs');
  process.exitCode = 1;
} else {
  const a = getAuth();
  console.log('登录状态：已登录');
  console.log(`  JWT：${String(a.jwt || '').slice(0, 16)}…`);
  console.log(`  device_mid：${a.deviceMid}`);
  console.log(`  登录时间：${a.savedAt}`);
}

try {
  const res = await fetch(`${base}/status`, {
    headers: { Authorization: `Bearer ${cfg.apiKey}` },
    signal: AbortSignal.timeout(20000),
  });
  const json = await res.json();
  const ents = json?.quota?.plan?.entitlements || [];
  console.log('\n免费额度（Start Plan）：');
  for (const e of ents) {
    console.log(
      `  ${e.showName}：${Number(e.grantUnits).toLocaleString()} token / ${e.period === 'daily' ? '日' : e.period}`,
    );
  }
  if (json?.quota?.balances) {
    console.log('\n账户余额明细：');
    for (const b of json.quota.balances) {
      console.log(
        `  ${b.show_name || b.showName || b.model}：剩余 ${b.remaining_units ?? b.remainingUnits ?? '?'} / 共 ${b.total_units ?? b.totalUnits ?? '?'}`,
      );
    }
  }
  if (json?.quota?.error) console.log(`\n额度查询提示：${json.quota.error}`);
} catch (e) {
  console.log(`\n（本地服务未启动，跳过在线额度查询：${e.message}）`);
}
