# ZCode app-server 协议速查（下一步：把后端从 `--prompt` 换成常驻 app-server）

> 状态：**已探明协议骨架，尚未实现**。当前可用后端是 `--prompt` 模式（见 `src/cli-backend.mjs`）。
> 本文记录逆向 + 参考开源实现得到的结论，供下一步直接动手。

## 1. 为什么值得换

当前 `--prompt` 模式每次请求都要冷启一个 Node 进程（30–50s），且只有最终文本、没有 token 用量、
没有原生工具调用。换成常驻的 `zcode app-server --stdio` 后可获得：

- 常驻进程：无冷启开销，延迟显著下降
- **真流式**：逐事件下发（而不是本文现在的「一次性文本」）
- 会话复用（`session/resume` / `session/load`）→ 真多轮上下文
- 原生工具调用、skills、MCP、自动压缩

## 2. 启动方式

```
node <ZCode安装目录>/resources/glm/zcode.cjs app-server --stdio
```

`zcode --help` 里写的是 “app-server  Run the ZCode Protocol stdio app server”。

## 3. 传输与消息格式（**不是 JSON-RPC**）

一行一个 JSON 对象（`JSON.stringify(msg) + "\n"`），stdin/stdout 双向。
**不要带 `jsonrpc` 字段** —— 带了会被拒：`Invalid ZCode Protocol message / Unrecognized key: "jsonrpc"`。

| 方向 | 形态 |
|---|---|
| 客户端 → 服务端（请求） | `{"id": <n>, "method": "...", "params": {...}}` |
| 客户端 → 服务端（通知） | `{"method": "...", "params": {...}}` |
| 服务端 → 客户端（应答） | `{"id": <n>, "result": {...}}` 或 `{"id": <n>, "error": {"code": -32004, "message": "..."}}` |
| 服务端 → 客户端（通知） | `{"method": "session/event", "params": {...}}`、`{"method": "state.updated", "params": {...}}` |
| 服务端 → 客户端（请求，需应答） | `{"id": <n>, "method": "session/requestRuntimePreferences", "params": {...}}` |

### 必须处理的握手

较新的 app-server 会**阻塞 `session/create`**，直到客户端应答 `session/requestRuntimePreferences`：

```js
{ id, result: {
    nativeSearchEnhancementsEnabled: false,
    memoryEnabled: false,
    askUserQuestionAutoResolutionEnabled: false,   // 保持 false，否则 AskUserQuestion 会被自动解决
} }
```

不应答 → `session/create` 永久挂起。

## 4. 方法清单（从 `zcode-acp-server` 0.37.1 提取）

```
session/create      session/send        session/subscribe   session/stop
session/close       session/list        session/load        session/resume
session/messages    session/compact     session/fork        session/goal
session/setMode     session/setModel    session/setThoughtLevel
session/updateRuntimeModelConfig        session/cancelBackgroundTask
session/request_permission
```

- 事件流方法名：`session/event`（按 sessionId 分发）；另有 `state.updated`。
- 参考实现里 **`session/create` 用的是 mode `yolo`**（硬编码）。
- **`session/prompt` 的时序是「先 subscribe 再 send」**，否则会漏掉开头的事件。

## 5. 未知/待确认

- `session/create` / `session/send` 的 **params 精确字段**（下一步第一件事）
- `session/event` 的事件体字段（文本增量、工具调用、用量）
- 会话空闲回收：约 10 分钟 idle + LRU，之后 session-scoped RPC 会返回 `-32004 Session is not active`，
  需要 `session/resume` 重新加载

## 6. 捷径：直接读开源实现（Apache-2.0）

不必自己逆向完 —— 下载 npm 包读它的实现即可（本仓库已下载到 `_ref/`）：

```powershell
npm pack zcode-acp-server           # 或从 registry.npmjs.org 下 tarball
tar -xzf zcode-acp-server-*.tgz -C _ref/zcode-acp
```

关键文件：

| 文件 | 内容 |
|---|---|
| `dist/backend/client.js` | ← **协议客户端**：成帧、请求/应答/通知、`session/requestRuntimePreferences` 自动应答 |
| `dist/handlers/session.js` | 会话生命周期与 turn 循环（subscribe-before-send、超时、失速对账） |
| `dist/translators/event-translator.js` | ZCode 事件 → 协议事件 的翻译表（**事件字段从这里抄最快**） |
| `dist/config/provider-registry.js` | provider 配置读取方式 |
| `dist/backend/credentials.js` | 凭据位置（`~/.zcode`） |

> 注意：该包是 **ACP**（Agent Client Protocol）服务端，面向 Zed/JetBrains，**Trae 用不了**。
> 我们只借它的 ZCode Protocol 知识，前端仍用本项目自己的 OpenAI/Anthropic 接口。

## 7. 与验证码的关系（重要）

换成 app-server **不改变验证码的玩法**：请求最终仍打到上游 Plan 通道，
而阿里云无痕验证参数仍是必需且一次性的。

所以架构保持：

```
Trae → 本项目 /v1/* ─→ zcode app-server --stdio（常驻，替代现在的 --prompt）
                          └→ 本项目 /internal/plan（逐请求注入验证码）→ zcode.z.ai
```

把 CLI 的 provider `baseURL` 指向 `http://127.0.0.1:8789/internal/plan` 即可（`prepareCliConfig()` 已实现）。
