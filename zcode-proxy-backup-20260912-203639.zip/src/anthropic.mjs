// /v1/messages：Anthropic Messages 入口（Claude Code / Trae 的 Anthropic 格式）。
// 上游本身就是 Anthropic 协议，这里近乎透传，只做模型名归一与参数钳制。
import { readJsonBody, startSSE, writeAsync, estimateTokens } from './util.mjs';
import { normalizeAnthropic } from './convert.mjs';
import { callMessages, UpstreamError } from './upstream.mjs';
import { log, warn } from './log.mjs';

function anthropicError(res, status, message, type = 'api_error') {
  const body = JSON.stringify({ type: 'error', error: { type, message } });
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(body);
}

export async function handleMessages(req, res, cfg, captcha) {
  // CLI / app-server 后端：交给官方客户端跑，再按 Anthropic 协议回写
  if (['cli', 'appserver'].includes(cfg.backend || 'cli')) {
    const { handleWithCli } = await import('./cli-backend.mjs');
    return handleWithCli(req, res, cfg, captcha, { anthropic: true });
  }

  const body = await readJsonBody(req);
  const payload = normalizeAnthropic(body, cfg);
  const started = Date.now();

  try {
    const upstream = await callMessages(cfg, captcha, payload, { stream: Boolean(body.stream) });

    if (body.stream) {
      startSSE(res);
      for await (const chunk of upstream.body) {
        await writeAsync(res, chunk);
      }
      res.end();
      log('Anthropic 流式完成 ' + (Date.now() - started) + 'ms');
      return;
    }

    const text = await upstream.text();
    res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    res.end(text);
    log('Anthropic 完成 ' + (Date.now() - started) + 'ms');
  } catch (e) {
    if (e instanceof UpstreamError) {
      warn('上游失败：' + e.message);
      anthropicError(res, e.status, e.message, e.type);
      return;
    }
    throw e;
  }
}

export async function handleCountTokens(req, res) {
  const body = await readJsonBody(req);
  let chars = 0;
  for (const m of body.messages || []) {
    if (typeof m.content === 'string') chars += m.content.length;
    else if (Array.isArray(m.content)) {
      for (const p of m.content) chars += (p?.text || '').length;
    }
  }
  if (typeof body.system === 'string') chars += body.system.length;
  res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
  res.end(JSON.stringify({ input_tokens: estimateTokens('x'.repeat(chars)) }));
}
