// CLI 后端：把官方 ZCode CLI 当作模型后端来驱动。
//
// 为什么走这条路（2026-09-12 实测）：
//   自己冒充 HTTP 协议会被上游判 3012「unusual activity」（连官方桌面端都被一起拦），
//   而官方 CLI 是正版客户端 —— 指纹、版本、凭证全由它自己处理，请求能过风控；
//   它唯一缺的是**无痕验证码头**（无头 CLI 没有浏览器解不了阿里云验证），
//   而这正是本项目的验证码求解器能补上的部分。
//
// 于是：官方 CLI（正版身份）+ 我们注入的验证码 → 免费额度可用。
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { promises as fsp } from 'node:fs';
import { paths } from './config.mjs';
import { log, warn } from './log.mjs';

export const CLI_CONFIG = path.join(os.homedir(), '.zcode', 'cli', 'config.json');
const APP_CONFIG = path.join(os.homedir(), '.zcode', 'v2', 'config.json');

/** 找到本机安装的官方 CLI（zcode.cjs）。 */
export function findCli(cfg) {
  if (cfg.cli?.path && fs.existsSync(cfg.cli.path)) return cfg.cli.path;
  const roots = [
    path.join(process.env.LOCALAPPDATA || '', 'Programs', 'ZCode', 'resources', 'glm', 'zcode.cjs'),
    path.join(process.env.ProgramFiles || '', 'ZCode', 'resources', 'glm', 'zcode.cjs'),
    '/Applications/ZCode.app/Contents/Resources/glm/zcode.cjs',
    path.join(os.homedir(), 'Applications', 'ZCode.app', 'Contents', 'Resources', 'glm', 'zcode.cjs'),
  ];
  for (const p of roots) {
    if (p && fs.existsSync(p)) return p;
  }
  return null;
}

/** 从官方应用的配置里取模型 provider（拿凭证与 baseURL）。 */
function readAppProvider(cfg) {
  const providerId = cfg.cli?.providerId || 'builtin:bigmodel-start-plan';
  if (!fs.existsSync(APP_CONFIG)) return null;
  const app = JSON.parse(fs.readFileSync(APP_CONFIG, 'utf8'));
  const entry = app.provider?.[providerId] || app.provider?.['builtin:zai-start-plan'];
  if (!entry?.options?.apiKey) return null;
  return { providerId: providerId.replace(/^builtin:/, ''), name: entry.name, options: entry.options, models: entry.models };
}

/** 列出官方应用里可用的 provider（供 /status 展示）。 */
export function listProviders() {
  if (!fs.existsSync(APP_CONFIG)) return [];
  try {
    const app = JSON.parse(fs.readFileSync(APP_CONFIG, 'utf8'));
    return Object.entries(app.provider || {}).map(([id, v]) => ({
      id,
      name: v.name,
      baseURL: v.options?.baseURL,
      enabled: v.enabled !== false,
      models: Object.keys(v.models || {}),
    }));
  } catch {
    return [];
  }
}

/**
 * 配置官方 CLI：把 provider 的 baseURL 指向本服务的内部 Plan 代理，
 * 由该代理**逐请求**注入新鲜验证码后再转发上游。
 *
 * 不再把验证码写死在配置里：CLI 一次 prompt 会发多个请求，而无痕验证参数是一次性的，
 * 写死只能供第一个请求用，后续必然 3007。
 */
export async function prepareCliConfig(cfg) {
  const src = readAppProvider(cfg);
  if (!src) throw new Error('读不到官方应用的 provider 配置（~/.zcode/v2/config.json）');

  const internalBase = `http://127.0.0.1:${cfg.port}/internal/plan`;
  const cliCfg = {
    $schema: 'https://zcode.z.ai/schema/cli-config.json',
    provider: {
      [src.providerId]: {
        kind: 'anthropic',
        name: src.name || 'ZCode Start Plan',
        // 打本服务的内部 Plan 代理（不是真上游）：验证码在那里逐请求注入
        options: { apiKey: src.options.apiKey, baseURL: internalBase },
        models: src.models,
      },
    },
    model: { main: `${src.providerId}/${cfg.cli?.model || cfg.defaultModel}` },
  };

  await fsp.mkdir(path.dirname(CLI_CONFIG), { recursive: true });
  await fsp.writeFile(CLI_CONFIG, JSON.stringify(cliCfg, null, 2));
  return internalBase;
}

/** 把 OpenAI 风格的消息拼成 CLI 的单个 prompt。 */
export function buildPrompt(messages, systemText) {
  const lines = [];
  if (systemText) lines.push(`[系统指令]\n${systemText}\n`);
  const convo = messages.filter((m) => m.role !== 'system' && m.role !== 'developer');
  if (convo.length === 1 && convo[0].role === 'user') {
    const text = textOf(convo[0].content);
    return systemText ? `[系统指令]\n${systemText}\n\n${text}` : text;
  }
  lines.push('[历史对话]');
  for (const m of convo.slice(0, -1)) {
    lines.push(`${m.role === 'user' ? '用户' : '助手'}：${textOf(m.content)}`);
  }
  const last = convo[convo.length - 1];
  lines.push('');
  lines.push(`[当前问题]\n${textOf(last?.content)}`);
  lines.push('');
  lines.push('请只回答当前问题，直接给出回答内容，不要复述历史、不要输出计划或步骤清单。');
  return lines.join('\n');
}

function textOf(content) {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content.map((p) => (typeof p === 'string' ? p : p?.text || '')).filter(Boolean).join('\n');
  }
  return '';
}

/**
 * CLI 后端的统一入口：把 Trae 的请求交给官方 CLI，再按客户端要求的协议回写。
 * anthropic=true 时用 Anthropic Messages 事件格式，否则用 OpenAI 格式。
 */
export async function handleWithCli(req, res, cfg, captcha, { anthropic = false } = {}) {
  const { readJsonBody, sendJson, sendError, startSSE, writeSSE, writeSSEEvent } = await import('./util.mjs');
  const { normalizeModel } = await import('./config.mjs');

  const body = await readJsonBody(req);
  const model = normalizeModel(body.model, cfg);
  const messages = Array.isArray(body.messages) ? body.messages : [];
  const systemText = messages
    .filter((m) => m.role === 'system' || m.role === 'developer')
    .map((m) => textOf(m.content))
    .filter(Boolean)
    .join('\n\n');

  const ac = new AbortController();
  req.on('close', () => {
    if (!res.writableEnded) ac.abort();
  });

  let text;
  let ms = 0;
  try {
    // 每次调用前刷新 CLI 配置（把 baseURL 指向本服务的内部 Plan 代理）
    await prepareCliConfig(cfg);
    const prompt = buildPrompt(messages, systemText);
    if ((cfg.backend || 'cli') === 'appserver') {
      // 实验性：常驻 app-server 后端（config.json 里把 backend 改成 "appserver" 启用）
      const { runAppServerPrompt } = await import('./appserver-backend.mjs');
      const t0 = Date.now();
      const out = await runAppServerPrompt(cfg, prompt, { signal: ac.signal });
      text = out.text;
      ms = Date.now() - t0;
    } else {
      const out = await runCli(cfg, prompt, { signal: ac.signal });
      text = out.text;
      ms = out.ms;
    }
  } catch (e) {
    const status = /验证码/.test(e.message) ? 503 : /风控|3012/.test(e.message) ? 429 : 502;
    if (anthropic) {
      res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ type: 'error', error: { type: 'upstream_error', message: e.message } }));
    } else {
      sendError(res, status, e.message, 'upstream_error');
    }
    return;
  }

  const id = `chatcmpl_${Date.now().toString(36)}`;

  if (!body.stream) {
    if (anthropic) {
      sendJson(res, 200, {
        id,
        type: 'message',
        role: 'assistant',
        model,
        content: [{ type: 'text', text }],
        stop_reason: 'end_turn',
        stop_sequence: null,
        usage: { input_tokens: 0, output_tokens: 0 },
      });
    } else {
      sendJson(res, 200, {
        id,
        object: 'chat.completion',
        created: Math.floor(Date.now() / 1000),
        model,
        choices: [{ index: 0, message: { role: 'assistant', content: text }, finish_reason: 'stop' }],
        usage: { prompt_tokens: 0, completion_tokens: 0, total_tokens: 0 },
      });
    }
    return;
  }

  startSSE(res);
  if (anthropic) {
    await writeSSEEvent(res, 'message_start', JSON.stringify({
      type: 'message_start',
      message: { id, type: 'message', role: 'assistant', model, content: [], usage: { input_tokens: 0, output_tokens: 0 } },
    }));
    await writeSSEEvent(res, 'content_block_start', JSON.stringify({ type: 'content_block_start', index: 0, content_block: { type: 'text', text: '' } }));
    await writeSSEEvent(res, 'content_block_delta', JSON.stringify({ type: 'content_block_delta', index: 0, delta: { type: 'text_delta', text } }));
    await writeSSEEvent(res, 'content_block_stop', JSON.stringify({ type: 'content_block_stop', index: 0 }));
    await writeSSEEvent(res, 'message_delta', JSON.stringify({ type: 'message_delta', delta: { stop_reason: 'end_turn' }, usage: { output_tokens: 0 } }));
    await writeSSEEvent(res, 'message_stop', JSON.stringify({ type: 'message_stop' }));
  } else {
    const chunk = (delta, finish = null) =>
      JSON.stringify({
        id,
        object: 'chat.completion.chunk',
        created: Math.floor(Date.now() / 1000),
        model,
        choices: [{ index: 0, delta, finish_reason: finish }],
      });
    await writeSSE(res, chunk({ role: 'assistant', content: '' }));
    await writeSSE(res, chunk({ content: text }));
    await writeSSE(res, chunk({}, 'stop'));
    await writeSSE(res, '[DONE]');
  }
  res.end();
  log(`CLI 后端响应完成（${ms}ms，${text.length} 字符，${anthropic ? 'Anthropic' : 'OpenAI'} 协议流式）`);
}

/** 串行队列：CLI 调用有并发上限，且同账号并发会被上游 3009 拒。 */
let chain = Promise.resolve();
function serialize(task) {
  const next = chain.then(task, task);
  chain = next.catch(() => {});
  return next;
}

/**
 * 跑一次 CLI 拿回答。
 * 用文件接 stdout/stderr（管道 stdio 在受限环境会 EPERM）。
 */
/**
 * 跑一次 CLI 拿回答（带 3009 并发退避重试）。
 * 免费额度同一模型只允许 1 个并发，上一个请求槽位未释放时会返回 3009，
 * 这里退避后重试，避免直接失败给客户端。
 */
export function runCli(cfg, prompt, { signal } = {}) {
  const maxAttempts = cfg.cli?.concurrencyRetries ?? 3;
  return serialize(async () => {
    let lastErr;
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await runCliOnce(cfg, prompt, { signal });
      } catch (e) {
        lastErr = e;
        const concurrency = /3009|concurrency/i.test(e.message);
        if (!concurrency || attempt === maxAttempts) throw e;
        const waitMs = 5000 * attempt;
        warn(`上游并发受限（3009），${waitMs / 1000}s 后重试（第 ${attempt}/${maxAttempts} 次）`);
        await new Promise((r) => setTimeout(r, waitMs));
        if (signal?.aborted) throw new Error('客户端已断开');
      }
    }
    throw lastErr;
  });
}

function runCliOnce(cfg, prompt, { signal } = {}) {
  // 注意：这里**不再**自己 serialize —— 外层 runCli 已经串行化了，
  // 再包一层会自我排队造成死锁。
  return (async () => {
    const cliPath = findCli(cfg);
    if (!cliPath) throw new Error('未找到官方 ZCode CLI（zcode.cjs）');

    const mode = cfg.cli?.mode || 'plan';
    const timeoutMs = cfg.cli?.timeoutMs || 240000;
    const stamp = `${process.pid}-${Date.now()}`;
    const outFile = path.join(paths.root, `.cli-${stamp}.out`);
    const errFile = path.join(paths.root, `.cli-${stamp}.err`);

    const args = [cliPath, '--prompt', prompt, '--mode', mode, '--no-color'];
    const t0 = Date.now();

    return await new Promise((resolve, reject) => {
      let settled = false;
      let outFd;
      let errFd;
      try {
        outFd = fs.openSync(outFile, 'w');
        errFd = fs.openSync(errFile, 'w');
      } catch (e) {
        reject(new Error(`无法创建 CLI 输出文件：${e.message}`));
        return;
      }
      const cleanup = () => {
        for (const fd of [outFd, errFd]) {
          try {
            fs.closeSync(fd);
          } catch {}
        }
      };
      const readBoth = () => {
        let out = '';
        let err = '';
        try {
          out = fs.readFileSync(outFile, 'utf8');
        } catch {}
        try {
          err = fs.readFileSync(errFile, 'utf8');
        } catch {}
        return { out, err };
      };
      const finish = (fn, value) => {
        if (settled) return;
        settled = true;
        cleanup();
        setTimeout(() => {
          for (const f of [outFile, errFile]) {
            try {
              fs.unlinkSync(f);
            } catch {}
          }
        }, 500).unref?.();
        fn(value);
      };

      let child;
      try {
        child = spawn(process.execPath, args, {
          cwd: paths.root,
          windowsHide: true,
          stdio: ['ignore', outFd, errFd],
        });
      } catch (e) {
        finish(reject, new Error(`无法启动 CLI：${e.message}`));
        return;
      }

      const timer = setTimeout(() => {
        try {
          child.kill();
        } catch {}
        const { out } = readBoth();
        finish(reject, new Error(`CLI 超时（${timeoutMs}ms），已产出 ${out.length} 字符`));
      }, timeoutMs);

      if (signal) {
        signal.addEventListener(
          'abort',
          () => {
            try {
              child.kill();
            } catch {}
            clearTimeout(timer);
            finish(reject, new Error('客户端已断开'));
          },
          { once: true },
        );
      }

      child.on('error', (e) => {
        clearTimeout(timer);
        finish(reject, new Error(`CLI 启动失败：${e.message}`));
      });

      child.on('close', (code) => {
        clearTimeout(timer);
        const { out, err } = readBoth();
        const text = out.trim();
        const ms = Date.now() - t0;

        if (text) {
          log(`CLI 完成 ${ms}ms（exit=${code}）输出 ${text.length} 字符`);
          finish(resolve, { text, ms, exitCode: code, stderr: err });
          return;
        }
        // 无 stdout：从 stderr 里提取上游业务错误
        const biz = /providerCode:\s*(\d+)/.exec(err);
        const msg = /providerMessage:\s*'([^']+)'/.exec(err);
        const detail = err.split(/\r?\n/).find((l) => /Error|error/.test(l)) || 'CLI 无输出';
        finish(reject, new Error(`CLI 失败${biz ? `（上游码 ${biz[1]}）` : ''}：${msg ? msg[1] : detail.slice(0, 200)}`));
      });
    });
  })();
}
