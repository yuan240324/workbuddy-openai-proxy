// 【实验性·默认不启用】app-server 后端：常驻驱动官方 `zcode app-server --stdio`。
//
// 相比 cli-backend（每次 --prompt 冷启一个进程），这里常驻一个 app-server 进程，
// 通过 ZCode Protocol（行分隔 JSON，**不是 JSON-RPC**）持续对话：
//   - 无冷启开销
//   - 可拿到逐事件流（session/event）
//   - 会话可复用（session/resume）
//
// 协议细节见 docs/app-server-protocol.md；参数实测自开源实现 zcode-acp-server 0.37.1：
//   session/create  {workspace, mode:"yolo"}          → {session:{sessionId}}
//   session/send    {sessionId, content}              → {accepted:true}（1308 = 忙）
//   session/subscribe {sessionId}                     ← 必须先订阅再 send
//   握手：服务端会阻塞 session/create，直到客户端应答 session/requestRuntimePreferences
//
// 启用方式：config.json 里把 backend 改成 "appserver"。
// 注意：本模块的事件字段解析是「启发式」的，首次使用请设 ZCODE_DUMP=1 观察真实事件。
import { spawn } from 'node:child_process';
import path from 'node:path';
import { findCli, cliEnv } from './cli-backend.mjs';
import { paths } from './config.mjs';
import { log, warn } from './log.mjs';

const IDLE_FINISH_MS = 6000; // 首段文本后再无事件多久算这一轮结束
const MAX_TURN_MS = 180000;
const DUMP = Boolean(process.env.ZCODE_DUMP);

class AppServer {
  constructor(cfg) {
    this.cfg = cfg;
    this.proc = null;
    this.nextId = 1;
    this.pending = new Map(); // id -> {resolve, reject, timer}
    this.buf = '';
    this.listeners = new Map(); // sessionId -> Set<fn>
    this.ready = null;
    this.dump = Boolean(process.env.ZCODE_DUMP);
  }

  async ensure() {
    if (this.proc && !this.proc.killed) return;
    if (this.ready) return this.ready;

    const cli = findCli(this.cfg);
    if (!cli) throw new Error('未找到官方 ZCode CLI（zcode.cjs）');

    this.ready = (async () => {
      const child = spawn(process.execPath, [cli, 'app-server', '--stdio'], {
        cwd: paths.root,
        windowsHide: true,
        stdio: ['pipe', 'pipe', 'pipe'],
        env: cliEnv(this.cfg),
      });
      this.proc = child;

      child.stdout.setEncoding('utf8');
      child.stdout.on('data', (d) => this.onData(d));
      child.stderr.setEncoding('utf8');
      child.stderr.on('data', (d) => {
        const s = String(d).trim();
        if (s) warn('[app-server]', s.slice(0, 300));
      });
      child.on('close', (code) => {
        warn(`app-server 退出（code=${code}）`);
        this.proc = null;
        this.ready = null;
        for (const [, p] of this.pending) p.reject(new Error('app-server 已退出'));
        this.pending.clear();
      });
      child.on('error', (e) => warn('app-server 启动失败：', e.message));
      log('app-server 已启动（常驻）');
    })();
    return this.ready;
  }

  onData(chunk) {
    this.buf += chunk;
    let i;
    while ((i = this.buf.indexOf('\n')) >= 0) {
      const line = this.buf.slice(0, i).trim();
      this.buf = this.buf.slice(i + 1);
      if (!line) continue;
      let msg;
      try {
        msg = JSON.parse(line);
      } catch {
        if (this.dump) warn('[app-server 非 JSON]', line.slice(0, 200));
        continue;
      }
      this.dispatch(msg);
    }
  }

  dispatch(msg) {
    if (this.dump) log('[app-server ←]', JSON.stringify(msg).slice(0, 400));

    // 应答：有 id、无 method
    if (msg.id !== undefined && msg.method === undefined) {
      const p = this.pending.get(msg.id);
      if (p) {
        this.pending.delete(msg.id);
        clearTimeout(p.timer);
        p.resolve(msg);
      }
      return;
    }

    // 服务端 → 客户端 请求：必须应答，否则 session/create 会一直挂住
    if (msg.id !== undefined && msg.method !== undefined) {
      if (msg.method === 'session/requestRuntimePreferences') {
        this.write({
          id: msg.id,
          result: {
            nativeSearchEnhancementsEnabled: false,
            memoryEnabled: false,
            askUserQuestionAutoResolutionEnabled: false,
          },
        });
        log('已应答 session/requestRuntimePreferences（默认偏好）');
      } else {
        // 其它服务端请求一律给个空结果，避免对端等待
        this.write({ id: msg.id, result: {} });
        warn(`未处理的 app-server 请求：${msg.method}（已空应答）`);
      }
      return;
    }

    // 通知：session/event 等
    if (msg.method === 'session/event') {
      const sid = msg.params?.sessionId ?? msg.params?.event?.sessionId;
      for (const fn of this.listeners.get(sid) || []) fn(msg.params);
      for (const fn of this.listeners.get('*') || []) fn(msg.params);
      return;
    }
    if (msg.method === 'state.updated') {
      for (const fn of this.listeners.get(msg.params?.sessionId) || []) fn({ type: 'state.updated', ...msg.params });
    }
  }

  write(obj) {
    if (!this.proc?.stdin?.writable) throw new Error('app-server 未就绪');
    this.proc.stdin.write(JSON.stringify(obj) + '\n');
  }

  request(method, params, timeoutMs = 15000) {
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`${method} 超时（${timeoutMs}ms）`));
      }, timeoutMs);
      this.pending.set(id, { resolve, reject, timer });
      try {
        this.write({ id, method, params: params ?? {} });
      } catch (e) {
        clearTimeout(timer);
        this.pending.delete(id);
        reject(e);
      }
    });
  }

  subscribe(sessionId, fn) {
    if (!this.listeners.has(sessionId)) this.listeners.set(sessionId, new Set());
    this.listeners.get(sessionId).add(fn);
    return () => this.listeners.get(sessionId)?.delete(fn);
  }

  async createSession(workspace) {
    await this.ensure();
    // workspace 必须是对象（实测：传字符串会被拒 "workspace: expected object, received string"）
    const p = workspace || paths.root;
    const resp = await this.request(
      'session/create',
      { workspace: { workspacePath: p, workspaceKey: p }, mode: 'yolo' },
      30000,
    );
    if (resp.error) throw new Error(`session/create 失败：${resp.error.message}`);
    const sid = resp.result?.session?.sessionId;
    if (!sid) throw new Error('session/create 未返回 sessionId');
    return sid;
  }

  async stop() {
    try {
      this.proc?.kill();
    } catch {}
    this.proc = null;
    this.ready = null;
  }
}

let singleton = null;
export function getAppServer(cfg) {
  if (!singleton) singleton = new AppServer(cfg);
  return singleton;
}

/**
 * 从任意事件里尽力抽取文本增量。
 * 真实事件体是 { method:"session/event", params:{ type, payload:{...} } }；
 * 文本类事件的 type / 字段名尚未在真实成功响应里验证过，因此这里同时做两件事：
 *   1) 按已知候选字段抽取
 *   2) 只要 payload 里出现疑似文本的字段就打日志（ZCODE_DUMP=1 时），便于下次直接确认真实名字
 */
function extractDelta(params) {
  const e = params?.event ?? params ?? {};
  const type = String(e.type ?? e.kind ?? params?.type ?? '');
  const p = e.payload ?? e;

  const cand =
    (typeof p.delta === 'string' ? p.delta : undefined) ??
    p.delta?.text ??
    p.text_delta ??
    (type.includes('text_delta') ? p.text : undefined) ??
    (type === 'text' ? p.text : undefined) ??
    (type.includes('assistant_text') ? p.text : undefined);

  if (typeof cand === 'string' && cand) return cand;

  // 没抽到：如果这个事件的 type 看起来像文本类，说明字段名和预期不符 → 打出来
  if (DUMP && /text|delta|message|assistant|content/i.test(type)) {
    warn(`[appserver 文本事件待确认] type=${type} payload=${JSON.stringify(p).slice(0, 300)}`);
  }
  return '';
}

function isTurnEnd(params) {
  const e = params?.event ?? params ?? {};
  const t = String(e.type ?? e.kind ?? '').toLowerCase();
  const status = String(e.payload?.status ?? '').toLowerCase();
  return (
    t.includes('turn_completed') ||
    t.includes('turn_failed') ||
    t.includes('turn.terminal') ||
    t.includes('message_stop') ||
    t === 'completed' ||
    t === 'done' ||
    (t.includes('turn') && (status === 'failed' || status === 'completed'))
  );
}

/**
 * 跑一轮：建会话 → 订阅 → 发送 → 收集事件直到结束。
 * onText 会被逐段回调（可用于流式）。
 */
export async function runAppServerPrompt(cfg, prompt, { onText, signal, workspace } = {}) {
  const srv = getAppServer(cfg);
  await srv.ensure();

  const ws = workspace || cfg.cli?.workspace || path.join(paths.root, 'workspace');
  const sid = await srv.createSession(ws);

  let text = '';
  let finished = false;
  let turnError = null;
  let resolveDone;
  const done = new Promise((r) => (resolveDone = r));
  let idleTimer = null;

  const armIdle = () => {
    if (idleTimer) clearTimeout(idleTimer);
    idleTimer = setTimeout(() => {
      if (!finished) {
        finished = true;
        resolveDone();
      }
    }, IDLE_FINISH_MS);
  };

  const unsub = srv.subscribe(sid, (params) => {
    const d = extractDelta(params);
    if (d) {
      text += d;
      onText?.(d);
      armIdle();
    }
    // 抓上游错误（如 3012 风控 / 3007 验证码），别让它变成「空回复」
    const ev = params?.event ?? params ?? {};
    const payload = ev.payload ?? {};
    const code = payload.errorCode ?? payload.error?.code;
    const msg =
      payload.errorMessage ??
      payload.error?.message ??
      payload.error?.providerMessage ??
      (typeof payload.error === 'string' ? payload.error : undefined);
    if (code || msg) turnError = { code, message: String(msg ?? '') };
    if (isTurnEnd(params)) {
      finished = true;
      resolveDone();
    }
  });

  const hardTimer = setTimeout(() => {
    if (!finished) {
      finished = true;
      resolveDone();
    }
  }, MAX_TURN_MS);

  try {
    // 先订阅再发送（否则会漏掉开头的事件）
    // deliveryKind 必填，取值实测为 "desktop-continuous" | "web-remote-replayable"
    await srv
      .request('session/subscribe', { sessionId: sid, deliveryKind: 'desktop-continuous' }, 15000)
      .catch((e) => {
        warn('session/subscribe 失败（继续尝试发送）：', e.message);
      });

    const send = await srv.request('session/send', { sessionId: sid, content: prompt }, 20000);
    if (send.error) {
      const code = send.error.code;
      throw new Error(`${code === 1308 ? '会话忙（1308）' : 'session/send 失败'}：${send.error.message}`);
    }

    armIdle();
    await done;
    const out = text.trim();
    if (!out && turnError) {
      const c = turnError.code ? `（上游码 ${turnError.code}）` : '';
      throw new Error(`app-server 轮次失败${c}：${turnError.message}`);
    }
    return { text: out, sessionId: sid };
  } finally {
    clearTimeout(hardTimer);
    if (idleTimer) clearTimeout(idleTimer);
    unsub();
    if (signal?.aborted) warn('客户端已断开（app-server 这一轮可能仍在跑）');
  }
}
